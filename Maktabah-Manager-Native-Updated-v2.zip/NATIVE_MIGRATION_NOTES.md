# Maktabah Manager — Native Android Migration

This build replaces the Capacitor Android wrapper with a native Kotlin Android shell while preserving the existing Manager web UI.

## Native responsibilities
- Kotlin `MainActivity`
- AndroidX SplashScreen API
- AndroidX BiometricPrompt
- WebView with WebViewAssetLoader (`https://appassets.androidplatform.net/...`) so the local app has a secure HTTPS-like origin for web APIs
- System bar / IME insets bridge
- Native back handling
- Native APK build through Gradle + GitHub Actions
- Official Maktabah Manager launcher icon and full-screen startup artwork are bundled from the project branding assets

## Existing web UI retained
The contents of `manager/` are copied into `app/src/main/assets/www/` by the workflow. The existing Manager JavaScript remains the application layer.

## Biometric bridge
`manager/applock.js` first uses `window.androidBridge` on the native build. Capacitor biometric detection remains as a compatibility fallback for old web/Capacitor builds.

## Verification in CI
The workflow performs:
- JavaScript syntax checks
- native manifest checks
- biometric/splash/native bridge source checks
- Gradle APK build
- APK package/application label checks
- verification that `applock.js` and `native-shell.js` are packaged
- SHA-256 generation

## Branding
The native launcher uses the supplied Maktabah Manager icon artwork. The supplied full-screen Maktabah Manager artwork is also shown as a native-only WebView startup splash after the Android system splash. Old generated placeholder icon/vector resources are not used.
