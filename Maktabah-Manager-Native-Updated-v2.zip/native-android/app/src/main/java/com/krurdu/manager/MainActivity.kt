package com.krurdu.manager

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Window
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private var topDp = 0f
    private var bottomDp = 0f
    private var splashKeep = true
    private lateinit var assetLoader: WebViewAssetLoader

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        splash.setKeepOnScreenCondition { splashKeep }
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = LocalWebClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(this@MainActivity), "androidBridge")
        }
        setContentView(web)
        installInsets()
        installBackHandling()
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        main.postDelayed({ splashKeep = false }, 420)
    }

    private fun installInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(web) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val imeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            val density = resources.displayMetrics.density
            topDp = bars.top / density
            bottomDp = if (imeVisible) 0f else bars.bottom / density
            web.setPadding(0, 0, 0, if (imeVisible) ime.bottom else 0)
            pushInsets()
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(web)
    }

    private fun pushInsets() {
        val js = "window.__krInsets&&window.__krInsets($topDp,$bottomDp)"
        web.post { web.evaluateJavascript(js, null) }
    }

    private fun installBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    private fun setBarsDark(dark: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }

    private inner class LocalWebClient : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) = assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return request.url.host != "appassets.androidplatform.net"
        }
    }

    class AndroidBridge(private val activity: MainActivity) {
        @JavascriptInterface fun top(): Float = activity.topDp
        @JavascriptInterface fun bottom(): Float = activity.bottomDp
        @JavascriptInterface fun setDark(dark: Boolean) = activity.runOnUiThread { activity.setBarsDark(dark) }

        @JavascriptInterface
        fun checkBiometry(): String {
            val bm = BiometricManager.from(activity)
            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
            return when (bm.canAuthenticate(authenticators)) {
                BiometricManager.BIOMETRIC_SUCCESS -> "{\"isAvailable\":true,\"code\":\"ok\"}"
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "{\"isAvailable\":false,\"code\":\"biometryNotEnrolled\"}"
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "{\"isAvailable\":false,\"code\":\"biometryUnavailable\"}"
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "{\"isAvailable\":false,\"code\":\"noHardware\"}"
                else -> "{\"isAvailable\":false,\"code\":\"unavailable\"}"
            }
        }

        @JavascriptInterface
        fun authenticate(reason: String): Boolean {
            if (Looper.myLooper() == Looper.getMainLooper()) return false
            val latch = CountDownLatch(1)
            val result = AtomicBoolean(false)
            activity.runOnUiThread {
                val executor = ContextCompat.getMainExecutor(activity)
                val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { result.set(true); latch.countDown() }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { latch.countDown() }
                    override fun onAuthenticationFailed() { }
                })
                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Maktabah Manager")
                    .setSubtitle("Unlock with biometrics")
                    .setDescription(reason.ifBlank { "Verify your identity" })
                    .setNegativeButtonText("Use PIN")
                    .setConfirmationRequired(false)
                    .build()
                prompt.authenticate(info)
            }
            return try { latch.await(90, TimeUnit.SECONDS) && result.get() } catch (_: InterruptedException) { false }
        }
    }
}
