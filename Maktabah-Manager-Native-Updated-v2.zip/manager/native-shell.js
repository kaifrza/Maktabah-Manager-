/* APK shell: real status/navigation bar insets from the native side,
   app-mode flag for CSS, and status-bar icon colour that follows the theme. */
(function () {
  'use strict';
  var cap = window.Capacitor, bridge = window.KRInsets || window.androidBridge;
  var isApp = !!(bridge || (cap && cap.isNativePlatform && cap.isNativePlatform()));
  if (!isApp) return;
  var root = document.documentElement;
  root.classList.add('is-app');

  function apply(t, b) {
    t = Number(t) || 0; b = Number(b) || 0;
    root.style.setProperty('--sat', t + 'px');
    root.style.setProperty('--sab', b + 'px');
  }
  window.__krInsets = apply;
  try { if (bridge) apply(bridge.top(), bridge.bottom()); } catch (e) {}

  function bars() {
    var dark = !!(document.body && document.body.classList.contains('dark'));
    try { if (bridge) bridge.setDark(dark); } catch (e) {}
  }
  function watch() {
    bars();
    new MutationObserver(bars).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }
  if (document.body) watch(); else document.addEventListener('DOMContentLoaded', watch);
  window.addEventListener('orientationchange', function () {
    setTimeout(function () { try { if (bridge) apply(bridge.top(), bridge.bottom()); } catch (e) {} }, 350);
  });
})();
