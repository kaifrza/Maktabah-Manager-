/* Maktabah Manager - optional local 6-digit App Lock + biometric unlock.
   OFF by default. Turned on from More > App lock. The PIN never leaves the device.
   Exposes window.MKLock. */
(function () {
  'use strict';
  var KEY = 'mk_lock_v1', FKEY = 'mk_lock_fail_v1', THEME_KEY = 'krul_manager_theme', AWAY = 10000, ITER = 100000;
  var cap = window.Capacitor;
  function isNative() {
    cap = window.Capacitor || cap;
    try { if (cap && cap.isNativePlatform && cap.isNativePlatform()) return true; } catch (e) {}
    try { if (cap && cap.getPlatform && cap.getPlatform() !== 'web') return true; } catch (e) {}
    return !!(window.KRInsets || window.androidBridge);
  }
  var native = isNative();
  var Bio = null, bioWhy = 'checking';
  var nativeBridge = window.androidBridge || null;
  var st = null, pin = '', first = '', stage = 'unlock', purpose = 'unlock';
  var busy = false, authing = false, locked = false, hiddenAt = 0, autoBio = true, tick = 0;
  var ov, T, S, D, K, C, R, RN, RT, G, B1, B2, BX;
  try { st = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}

  var LOGO = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1024 1024\" width=\"100%\" height=\"100%\"><defs>\n<linearGradient id=\"mkbg\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#11694b\"/><stop offset=\".55\" stop-color=\"#0a4331\"/><stop offset=\"1\" stop-color=\"#062419\"/></linearGradient>\n<radialGradient id=\"mkg1\" cx=\".18\" cy=\".12\" r=\".7\"><stop offset=\"0\" stop-color=\"#6ee3b4\" stop-opacity=\".38\"/><stop offset=\"1\" stop-color=\"#6ee3b4\" stop-opacity=\"0\"/></radialGradient>\n<radialGradient id=\"mkg2\" cx=\".92\" cy=\".95\" r=\".7\"><stop offset=\"0\" stop-color=\"#e2b650\" stop-opacity=\".30\"/><stop offset=\"1\" stop-color=\"#e2b650\" stop-opacity=\"0\"/></radialGradient>\n<pattern id=\"mkpt\" width=\"128\" height=\"128\" patternUnits=\"userSpaceOnUse\"><polygon points=\"64.0,18.0 73.9,40.0 96.5,31.5 88.0,54.1 110.0,64.0 88.0,73.9 96.5,96.5 73.9,88.0 64.0,110.0 54.1,88.0 31.5,96.5 40.0,73.9 18.0,64.0 40.0,54.1 31.5,31.5 54.1,40.0\" fill=\"none\" stroke=\"#f0d98a\" stroke-width=\"2\" opacity=\".085\"/><circle cx=\"0\" cy=\"0\" r=\"5\" fill=\"#f0d98a\" opacity=\".07\"/><circle cx=\"128\" cy=\"0\" r=\"5\" fill=\"#f0d98a\" opacity=\".07\"/><circle cx=\"0\" cy=\"128\" r=\"5\" fill=\"#f0d98a\" opacity=\".07\"/><circle cx=\"128\" cy=\"128\" r=\"5\" fill=\"#f0d98a\" opacity=\".07\"/></pattern>\n<linearGradient id=\"mkpl\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#f0d68a\"/><stop offset=\".72\" stop-color=\"#d8b458\"/><stop offset=\"1\" stop-color=\"#b98f35\"/></linearGradient>\n<linearGradient id=\"mkpr\" x1=\"1\" y1=\"0\" x2=\"0\" y2=\"0\"><stop offset=\"0\" stop-color=\"#fbebb4\"/><stop offset=\".72\" stop-color=\"#e6c870\"/><stop offset=\"1\" stop-color=\"#c9a24b\"/></linearGradient>\n<linearGradient id=\"mkcv\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#a68232\"/><stop offset=\"1\" stop-color=\"#6a501c\"/></linearGradient>\n<linearGradient id=\"mkrb\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#52dca4\"/><stop offset=\"1\" stop-color=\"#1c9468\"/></linearGradient>\n<linearGradient id=\"mkst\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#fff4c4\"/><stop offset=\".6\" stop-color=\"#ecc765\"/><stop offset=\"1\" stop-color=\"#c79a35\"/></linearGradient>\n<radialGradient id=\"mkgl\" cx=\".5\" cy=\".5\" r=\".5\"><stop offset=\"0\" stop-color=\"#ffe9a0\" stop-opacity=\".55\"/><stop offset=\".5\" stop-color=\"#ffd978\" stop-opacity=\".16\"/><stop offset=\"1\" stop-color=\"#ffd978\" stop-opacity=\"0\"/></radialGradient>\n<filter id=\"mksh\" x=\"-20%\" y=\"-20%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"0\" dy=\"14\" stdDeviation=\"14\" flood-color=\"#021a11\" flood-opacity=\".55\"/></filter><clipPath id=\"mkcp\"><rect width=\"1024\" height=\"1024\" rx=\"232\"/></clipPath></defs><g clip-path=\"url(#mkcp)\"><rect width=\"1024\" height=\"1024\" fill=\"url(#mkbg)\"/><rect width=\"1024\" height=\"1024\" fill=\"url(#mkpt)\"/><rect width=\"1024\" height=\"1024\" fill=\"url(#mkg1)\"/><rect width=\"1024\" height=\"1024\" fill=\"url(#mkg2)\"/>\n<circle cx=\"512\" cy=\"338\" r=\"170\" fill=\"url(#mkgl)\"/>\n<circle cx=\"512\" cy=\"338\" r=\"122\" fill=\"none\" stroke=\"#f0d98a\" stroke-width=\"2.5\" opacity=\".30\"/>\n<g filter=\"url(#mksh)\">\n<path d=\"M512 522C446 482 340 472 252 504L252 704C340 678 446 686 512 726Z\" fill=\"url(#mkcv)\"/><path d=\"M512 522C578 482 684 472 772 504L772 704C684 678 578 686 512 726Z\" fill=\"url(#mkcv)\"/>\n<path d=\"M512 500C452 462 352 452 266 480L266 672C352 646 452 654 512 694Z\" fill=\"url(#mkpl)\"/><path d=\"M512 500C572 462 672 452 758 480L758 672C672 646 572 654 512 694Z\" fill=\"url(#mkpr)\"/>\n<g fill=\"none\" stroke=\"#0b3b2a\" stroke-opacity=\".42\" stroke-width=\"7\" stroke-linecap=\"round\"><path d=\"M306 520C366 502 436 510 486 546\" /><path d=\"M306 558C366 540 436 548 486 584\" /><path d=\"M306 596C366 578 436 586 486 622\" /><path d=\"M306 634C366 616 436 624 474 660\" /><path d=\"M718 520C658 502 588 510 538 546\" /><path d=\"M718 558C658 540 588 548 538 584\" /><path d=\"M718 596C658 578 588 586 538 622\" /><path d=\"M718 634C658 616 588 624 550 660\" /></g>\n<path d=\"M512 500V694\" stroke=\"#7d5f1f\" stroke-width=\"7\" stroke-linecap=\"round\"/>\n<path d=\"M505 500L505 742L512 728L519 742L519 500Z\" fill=\"url(#mkrb)\"/>\n</g>\n<g filter=\"url(#mksh)\"><polygon points=\"512.0,252.0 531.1,291.8 572.8,277.2 558.2,318.9 598.0,338.0 558.2,357.1 572.8,398.8 531.1,384.2 512.0,424.0 492.9,384.2 451.2,398.8 465.8,357.1 426.0,338.0 465.8,318.9 451.2,277.2 492.9,291.8\" fill=\"url(#mkst)\" stroke=\"#fff4c4\" stroke-opacity=\".6\" stroke-width=\"2\" stroke-linejoin=\"round\"/>\n<circle cx=\"512\" cy=\"338\" r=\"21\" fill=\"#0b4a35\" stroke=\"#f6dc8c\" stroke-width=\"5\"/></g></g><rect x=\"5\" y=\"5\" width=\"1014\" height=\"1014\" rx=\"228\" fill=\"none\" stroke=\"#e2c26a\" stroke-opacity=\".85\" stroke-width=\"10\"/><rect x=\"22\" y=\"22\" width=\"980\" height=\"980\" rx=\"212\" fill=\"none\" stroke=\"#ffffff\" stroke-opacity=\".16\" stroke-width=\"3\"/></svg>";
  var SP = 'var(--sat,env(safe-area-inset-top,0px))', SB = 'var(--sab,env(safe-area-inset-bottom,0px))';

  var CSS =
    '#mk-lock,#mk-lock *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}' +
    '#mk-lock{--ink:#10261e;--soft:rgba(16,38,30,.62);--bg:rgba(255,255,255,.52);--bg2:rgba(255,255,255,.64);--bd:rgba(255,255,255,.8);--hi:inset 0 1px 0 rgba(255,255,255,.9);--sh:0 24px 56px rgba(16,50,38,.16);--em:#176b4d;--em2:#0f593f;--gold:#b8903a;--key:rgba(255,255,255,.66);--err:#b23a3a;--track:rgba(16,38,30,.1);' +
    'position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:calc(20px + ' + SP + ') 16px calc(20px + ' + SB + ');color:var(--ink);font-family:Manrope,Inter,system-ui,-apple-system,"Segoe UI",sans-serif;overflow:auto;transition:opacity .22s ease;' +
    'background:radial-gradient(520px 420px at 10% 6%,rgba(94,214,170,.6),transparent 70%),radial-gradient(480px 460px at 94% 16%,rgba(122,170,255,.45),transparent 70%),radial-gradient(560px 520px at 82% 94%,rgba(255,206,140,.5),transparent 70%),radial-gradient(520px 480px at 4% 88%,rgba(180,150,255,.36),transparent 70%),linear-gradient(160deg,#e3f2ea,#dde8f5)}' +
    '#mk-lock.dark{--ink:#edf4ee;--soft:rgba(237,244,238,.66);--bg:rgba(22,34,28,.55);--bg2:rgba(255,255,255,.08);--bd:rgba(255,255,255,.14);--hi:inset 0 1px 0 rgba(255,255,255,.1);--sh:0 24px 56px rgba(0,0,0,.45);--em:#4fbd8a;--em2:#3aa675;--gold:#d9b45a;--key:rgba(255,255,255,.09);--err:#ff9a9a;--track:rgba(255,255,255,.12);' +
    'background:radial-gradient(520px 420px at 10% 6%,rgba(40,170,120,.38),transparent 70%),radial-gradient(480px 460px at 94% 16%,rgba(70,100,210,.34),transparent 70%),radial-gradient(560px 520px at 82% 94%,rgba(210,150,60,.2),transparent 70%),radial-gradient(520px 480px at 4% 88%,rgba(120,80,200,.24),transparent 70%),linear-gradient(160deg,#08140f,#0b1220)}' +
    '#mk-lock.out{opacity:0}' +
    '#mk-lock .mkc{position:relative;width:min(100%,380px);padding:26px 20px 18px;border-radius:36px;text-align:center;background:linear-gradient(145deg,var(--bg2),var(--bg));-webkit-backdrop-filter:blur(22px) saturate(165%);backdrop-filter:blur(22px) saturate(165%);border:1px solid var(--bd);box-shadow:var(--sh),var(--hi);animation:mkin .38s cubic-bezier(.2,.8,.2,1)}' +
    '@keyframes mkin{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}' +
    '#mk-lock .mkl{width:76px;height:76px;margin:0 auto 12px;border-radius:24px;box-shadow:0 14px 28px rgba(8,50,34,.28)}' +
    '#mk-lock .mkl svg{display:block;width:100%;height:100%}' +
    '#mk-lock .mkk{display:inline-block;padding:4px 12px;border-radius:999px;background:var(--bg2);border:1px solid var(--bd);box-shadow:var(--hi);font-size:.66rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--gold)}' +
    '#mk-lock h1{margin:12px 0 0;font-size:1.5rem;line-height:1.2;font-weight:800;letter-spacing:-.02em;color:var(--ink)}' +
    '#mk-s{margin:6px 0 0;min-height:20px;font-size:.86rem;line-height:1.35;color:var(--soft);transition:color .15s}' +
    '#mk-s.e{color:var(--err);font-weight:700}' +
    '#mk-d{display:flex;justify-content:center;gap:15px;margin:20px 0 22px}' +
    '#mk-d i{width:14px;height:14px;border-radius:50%;border:2px solid var(--gold);transition:background .14s,transform .14s,border-color .14s}' +
    '#mk-d i.on{background:linear-gradient(135deg,var(--em),var(--em2));border-color:var(--em);transform:scale(1.15)}' +
    '#mk-d.shake{animation:mksh .42s cubic-bezier(.36,.07,.19,.97)}' +
    '#mk-d.err i{border-color:var(--err)}#mk-d.err i.on{background:var(--err);border-color:var(--err)}' +
    '@keyframes mksh{10%,90%{transform:translateX(-2px)}20%,80%{transform:translateX(4px)}30%,50%,70%{transform:translateX(-8px)}40%,60%{transform:translateX(8px)}}' +
    '#mk-k{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;justify-items:center;transition:opacity .2s,filter .2s}' +
    '#mk-k button{width:70px;height:70px;border-radius:50%;border:1px solid var(--bd);background:var(--key);box-shadow:var(--hi);color:var(--ink);font-family:inherit;font-size:1.5rem;font-weight:700;display:grid;place-items:center;cursor:pointer;touch-action:manipulation;transition:transform .1s,background .15s}' +
    '#mk-k button:active{transform:scale(.92);background:linear-gradient(135deg,var(--em),var(--em2));color:#fff}' +
    '#mk-k button.fn{font-size:1.25rem;color:var(--em)}' +
    '#mk-k button.bio{background:linear-gradient(135deg,var(--em),var(--em2));color:#fff;border-color:transparent;box-shadow:0 8px 18px rgba(23,107,77,.3)}' +
    '#mk-k button.x{visibility:hidden}' +
    '#mk-k.off{opacity:.32;filter:grayscale(.4);pointer-events:none}' +
    '#mk-r{display:none;margin:18px auto 20px;position:relative;width:132px;height:132px}' +
    '#mk-r svg{width:132px;height:132px;transform:rotate(-90deg)}' +
    '#mk-r circle{fill:none;stroke-width:8;stroke-linecap:round}' +
    '#mk-r .t{stroke:var(--track)}#mk-r .p{stroke:var(--err);transition:stroke-dashoffset .3s linear}' +
    '#mk-r b{position:absolute;inset:0;display:grid;place-items:center;font-size:2.1rem;font-weight:800;font-variant-numeric:tabular-nums;color:var(--ink)}' +
    '#mk-g{display:none;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:22px}' +
    '#mk-g button,#mk-c{min-height:48px;padding:0 22px;border-radius:18px;border:1.5px solid var(--bd);background:var(--bg2);box-shadow:var(--hi);color:var(--ink);font-family:inherit;font-weight:750;font-size:.88rem;cursor:pointer;transition:transform .1s}' +
    '#mk-g button:active,#mk-c:active{transform:scale(.96)}' +
    '#mk-g button.pri{background:linear-gradient(135deg,var(--em),var(--em2));color:#fff;border-color:transparent}' +
    '#mk-c{margin-top:14px;display:none}' +
    '#mk-lock .mkn{margin:14px 0 0;font-size:.74rem;color:var(--soft)}' +
    '#mk-lock .mkn i{margin-right:6px;color:var(--em)}' +
    '@media(max-height:660px){#mk-lock .mkc{padding:16px 14px 12px}#mk-lock .mkl{width:54px;height:54px;border-radius:17px;margin-bottom:6px}#mk-lock h1{font-size:1.25rem;margin-top:8px}#mk-d{margin:12px 0 14px}#mk-k{gap:8px}#mk-k button{width:58px;height:58px;font-size:1.3rem}#mk-r{margin:10px auto 12px;transform:scale(.8)}}' +
    'html[data-perf="lite"] #mk-lock .mkc{-webkit-backdrop-filter:none;backdrop-filter:none;background:rgba(255,255,255,.95)}' +
    'html[data-perf="lite"] #mk-lock.dark .mkc{background:rgba(24,36,29,.97)}' +
    'html[data-perf="lite"] #mk-lock *{transition:none!important;animation:none!important}' +
    '@media(prefers-reduced-motion:reduce){#mk-lock *{transition:none!important;animation:none!important}}';

  function build() {
    if (ov) return;
    var s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s);
    ov = document.createElement('div');
    ov.id = 'mk-lock'; ov.style.display = 'none';
    ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true'); ov.setAttribute('aria-label', 'App lock');
    ov.innerHTML =
      '<section class="mkc">' +
      '<div class="mkl" aria-hidden="true">' + LOGO + '</div>' +
      '<span class="mkk">Maktabah Manager</span>' +
      '<h1 id="mk-t"></h1><p id="mk-s" aria-live="polite"></p>' +
      '<div id="mk-r" aria-hidden="true"><svg viewBox="0 0 132 132"><circle class="t" cx="66" cy="66" r="58"/><circle class="p" cx="66" cy="66" r="58" stroke-dasharray="364.4" stroke-dashoffset="0"/></svg><b id="mk-rn">0</b></div>' +
      '<div id="mk-d" aria-hidden="true"></div><div id="mk-k"></div>' +
      '<div id="mk-g"><button id="mk-b1" type="button" class="pri"></button><button id="mk-b2" type="button"></button></div>' +
      '<button id="mk-c" type="button">Cancel</button>' +
      '<p class="mkn"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i>Your PIN stays on this device only</p>' +
      '</section>';
    document.body.appendChild(ov);
    T = ov.querySelector('#mk-t'); S = ov.querySelector('#mk-s');
    D = ov.querySelector('#mk-d'); K = ov.querySelector('#mk-k'); C = ov.querySelector('#mk-c');
    R = ov.querySelector('#mk-r'); RN = ov.querySelector('#mk-rn'); RT = ov.querySelector('#mk-r .p');
    G = ov.querySelector('#mk-g'); B1 = ov.querySelector('#mk-b1'); B2 = ov.querySelector('#mk-b2');
    C.onclick = cancel;
  }
  function show() {
    build();
    ov.classList.toggle('dark', localStorage.getItem(THEME_KEY) === 'dark');
    ov.classList.remove('out');
    ov.style.display = 'grid';
  }
  function hide(fast) {
    clearInterval(tick); tick = 0; pin = ''; first = '';
    if (!ov) return;
    if (fast) { ov.style.display = 'none'; return; }
    ov.classList.add('out');
    setTimeout(function () { if (ov.classList.contains('out')) ov.style.display = 'none'; }, 230);
  }
  function changed() { try { window.dispatchEvent(new Event('mklockchange')); } catch (e) {} }

  function dots(err) {
    D.className = err ? 'err' : '';
    D.innerHTML = '';
    for (var i = 0; i < 6; i++) { var d = document.createElement('i'); if (i < pin.length) d.className = 'on'; D.appendChild(d); }
  }
  var TITLES = {
    unlock: ['Welcome back', 'Enter your PIN to unlock'],
    set: ['Create PIN', 'Choose a 6-digit PIN'],
    confirm: ['Confirm PIN', 'Enter the same PIN again'],
    old: ['Current PIN', 'Enter your current PIN to continue'],
    bioask: ['Quick unlock', 'Use your fingerprint or face to unlock faster?']
  };

  /* ---------- lockout timer ---------- */
  function fail() { try { return JSON.parse(localStorage.getItem(FKEY)) || { n: 0, until: 0, span: 0 }; } catch (e) { return { n: 0, until: 0, span: 0 }; } }
  function wait() { var f = fail(); return f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0; }
  function fmt(s) { return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function paintLock() {
    var f = fail(), left = f.until - Date.now();
    if (left <= 0) { clearInterval(tick); tick = 0; ui('You can try again now.'); return; }
    var sec = Math.ceil(left / 1000), span = Math.max(1000, f.span || left);
    RN.textContent = sec < 60 ? String(sec) : fmt(sec);
    RT.style.strokeDashoffset = String(364.4 * (1 - Math.min(1, left / span)));
    S.textContent = 'Too many attempts. Try again in ' + (sec < 60 ? sec + 's' : fmt(sec)) + '.';
  }
  function startLock() {
    clearInterval(tick);
    paintLock();
    tick = setInterval(paintLock, 250);
  }

  function ui(msg, err) {
    var t = TITLES[stage], w = (stage === 'unlock' || stage === 'old') ? wait() : 0;
    T.textContent = t[0];
    S.textContent = msg || t[1];
    S.className = err ? 'e' : '';
    C.style.display = purpose === 'unlock' ? 'none' : 'inline-block';
    var ask = stage === 'bioask';
    G.style.display = ask ? 'flex' : 'none';
    D.style.display = (ask || w) ? 'none' : 'flex';
    K.style.display = ask ? 'none' : 'grid';
    R.style.display = w ? 'block' : 'none';
    K.classList.toggle('off', !!w);
    if (ask) {
      B1.textContent = 'Enable'; B2.textContent = 'Not now';
      B1.onclick = async function () { var ok = await api.setBio(true); finishSetup(ok); };
      B2.onclick = function () { finishSetup(false); };
      return;
    }
    dots();
    K.innerHTML = '';
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'f', '0', 'b'].forEach(function (k) {
      var b = document.createElement('button');
      b.type = 'button';
      if (k === 'b') { b.className = 'fn'; b.setAttribute('aria-label', 'Delete'); b.innerHTML = '<i class="fa-solid fa-delete-left"></i>'; }
      else if (k === 'f') {
        if (st && st.bio && Bio && stage === 'unlock') { b.className = 'fn bio'; b.setAttribute('aria-label', 'Use biometrics'); b.innerHTML = '<i class="fa-solid fa-fingerprint"></i>'; }
        else b.className = 'x';
      } else b.textContent = k;
      b.onclick = function () { press(k); };
      K.appendChild(b);
    });
    if (w) startLock();
  }

  /* ---------- crypto ---------- */
  var enc = new TextEncoder();
  function hex(buf) { return Array.from(new Uint8Array(buf)).map(function (x) { return x.toString(16).padStart(2, '0'); }).join(''); }
  async function sha(s) { return hex(await crypto.subtle.digest('SHA-256', enc.encode(s))); }
  async function pbk(p, salt) {
    var key = await crypto.subtle.importKey('raw', enc.encode(p), 'PBKDF2', false, ['deriveBits']);
    return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: ITER }, key, 256));
  }
  function rnd() { var a = new Uint8Array(16); crypto.getRandomValues(a); return hex(a); }
  async function check(p) { return st.v === 2 ? (await pbk(p, st.salt)) === st.hash : (await sha(st.salt + p)) === st.hash; }
  async function upgrade(p) {
    if (!st || st.v === 2) return;
    try { st.hash = await pbk(p, st.salt); st.v = 2; save(); } catch (e) {}
  }
  function save() { localStorage.setItem(KEY, JSON.stringify(st)); }

  function wrong() {
    var f = fail(); f.n++;
    if (f.n % 5 === 0) {
      var secs = Math.min(300, 30 * Math.pow(2, f.n / 5 - 1));
      f.until = Date.now() + secs * 1000; f.span = secs * 1000;
    }
    localStorage.setItem(FKEY, JSON.stringify(f));
    var w = wait(), left = 5 - (f.n % 5);
    ui(w ? '' : (left <= 2 ? 'Incorrect PIN. ' + left + ' attempt' + (left > 1 ? 's' : '') + ' left before a timed lock.' : 'Incorrect PIN. Try again.'), !w);
    if (!w) { D.className = 'err shake'; setTimeout(function () { if (D) D.className = ''; }, 460); }
    if (navigator.vibrate) navigator.vibrate(w ? [80, 60, 80] : 120);
  }

  /* ---------- biometric ---------- */
  async function detect() {
    native = isNative();
    nativeBridge = window.androidBridge || null;
    if (nativeBridge && nativeBridge.checkBiometry) {
      try {
        var raw = nativeBridge.checkBiometry(), r = typeof raw === 'string' ? JSON.parse(raw) : raw;
        bioWhy = r && r.isAvailable ? 'ok' : ((r && r.code) || 'unavailable');
        Bio = nativeBridge;
        return;
      } catch (e) { bioWhy = 'error: ' + ((e && e.message) || 'unknown'); }
    }
    if (!native) { bioWhy = 'web'; return; }
    var names = ['BiometricAuthNative', 'BiometricAuth'];
    for (var i = 0; i < names.length; i++) {
      try {
        var p = null;
        if (cap && cap.registerPlugin && (!cap.isPluginAvailable || cap.isPluginAvailable(names[i]))) p = cap.registerPlugin(names[i]);
        else if (cap && cap.Plugins && cap.Plugins[names[i]]) p = cap.Plugins[names[i]];
        if (!p) continue;
        var r2 = await p.checkBiometry();
        if (r2 && r2.isAvailable) { Bio = p; bioWhy = 'ok'; return; }
        bioWhy = (r2 && r2.code === 'biometryNotEnrolled') ? 'not-enrolled' : 'unavailable';
        return;
      } catch (e) { bioWhy = 'error: ' + ((e && (e.message || e.code)) || 'unknown'); return; }
    }
    bioWhy = 'no-plugin';
  }
  var bioReady = detect();
  async function recheck() {
    await bioReady;
    if (!Bio && bioWhy !== 'not-enrolled') { bioReady = detect(); await bioReady; }
  }

  async function bioAuth(reason) {
    if (!Bio || authing || bioWhy !== 'ok') return false;
    authing = true;
    try {
      if (Bio === nativeBridge && Bio.authenticate) {
        var ok = !!Bio.authenticate(reason || 'Verify your identity');
        authing = false; return ok;
      }
      await Bio.authenticate({ reason: reason || 'Unlock Maktabah Manager', cancelTitle: 'Use PIN', allowDeviceCredential: false, androidTitle: 'Maktabah Manager', androidSubtitle: 'Unlock with biometrics', androidConfirmationRequired: false });
      authing = false; return true;
    } catch (e) {
      authing = false;
      var c = e && e.code;
      if (c === 'biometryLockout' && locked && ov) ui('Biometrics are locked. Use your PIN.', true);
      return false;
    }
  }
  async function tryBioUnlock() {
    if (locked && purpose === 'unlock' && stage === 'unlock' && st && st.bio && !wait() && await bioAuth()) unlock();
  }
  function unlock() { locked = false; localStorage.removeItem(FKEY); hide(); changed(); }
  function lock() {
    if (!st || locked) return;
    locked = true; purpose = 'unlock'; stage = 'unlock'; pin = ''; autoBio = true;
    show(); ui();
    setTimeout(function () { if (autoBio) tryBioUnlock(); }, 280);
  }
  function cancel() {
    if (purpose === 'unlock') return;
    purpose = 'unlock'; stage = 'unlock'; hide(); changed();
  }
  function finishSetup() { purpose = 'unlock'; stage = 'unlock'; hide(); changed(); }

  async function submit() {
    var p = pin; pin = '';
    if (stage === 'old') {
      if (await check(p)) {
        if (purpose === 'disable') {
          st = null; localStorage.removeItem(KEY); localStorage.removeItem(FKEY);
          purpose = 'unlock'; stage = 'unlock'; hide(); changed();
        } else { stage = 'set'; ui(); }
      } else wrong();
      return;
    }
    if (stage === 'set') { first = p; stage = 'confirm'; ui(); return; }
    if (stage === 'confirm') {
      if (p !== first) { first = ''; stage = 'set'; ui('PINs did not match. Try again.', true); return; }
      var salt = rnd(), bio = !!(st && st.bio), fresh = !st;
      st = { v: 2, salt: salt, hash: await pbk(p, salt), bio: bio }; save();
      await bioReady;
      if (fresh && Bio && !bio) { stage = 'bioask'; ui(); changed(); return; }
      purpose = 'unlock'; stage = 'unlock'; hide(); changed(); return;
    }
    if (await check(p)) { upgrade(p); unlock(); } else wrong();
  }
  async function press(k) {
    if (busy) return;
    if (k === 'f') { autoBio = true; tryBioUnlock(); return; }
    if (stage === 'unlock' || stage === 'old') { if (wait()) { ui(); return; } }
    if (k === 'b') { pin = pin.slice(0, -1); dots(); return; }
    if (pin.length >= 6) return;
    pin += k; dots();
    if (navigator.vibrate) navigator.vibrate(8);
    if (pin.length === 6) { busy = true; try { await submit(); } finally { busy = false; } }
  }

  /* ---------- auto-lock on return ---------- */
  function away() { if (st && !locked && !authing && !hiddenAt) hiddenAt = Date.now(); }
  function back() { if (hiddenAt && Date.now() - hiddenAt > AWAY) lock(); hiddenAt = 0; }
  document.addEventListener('visibilitychange', function () { document.hidden ? away() : back(); });
  try {
    if (native && cap.registerPlugin && (!cap.isPluginAvailable || cap.isPluginAvailable('App'))) {
      cap.registerPlugin('App').addListener('appStateChange', function (s) { s && s.isActive ? back() : away(); });
    }
  } catch (e) {}

  function flow(p, s) {
    if (locked) return;
    purpose = p; stage = s; pin = ''; first = '';
    show(); ui();
  }
  var api = window.MKLock = {
    isEnabled: function () { return !!st; },
    bioAvailable: async function () { await recheck(); return !!Bio && bioWhy === 'ok'; },
    bioStatus: async function () { await recheck(); return bioWhy; },
    bioEnabled: function () { return !!(st && st.bio); },
    setBio: async function (on) {
      await recheck();
      if (!st || !Bio || bioWhy !== 'ok') return false;
      if (on && !(await bioAuth('Enable biometric unlock'))) return false;
      st.bio = !!on; save(); changed(); return true;
    },
    enable: function () { if (!st) flow('enable', 'set'); },
    changePin: function () { if (st) flow('change', 'old'); },
    disable: function () { if (st) flow('disable', 'old'); },
    lockNow: function () { lock(); }
  };

  if (st) {
    locked = true;
    show(); ui();
    bioReady.then(function () { if (locked) { ui(); setTimeout(function () { if (autoBio) tryBioUnlock(); }, 200); } });
  }
})();
