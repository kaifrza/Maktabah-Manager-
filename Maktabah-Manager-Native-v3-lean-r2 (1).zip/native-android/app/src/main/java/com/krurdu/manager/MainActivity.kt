package com.krurdu.manager

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : FragmentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    @Volatile private var topDp = 0f
    @Volatile private var bottomDp = 0f
    private var splashKeep = true
    private var promptActive = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uris = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        splash.setKeepOnScreenCondition { splashKeep }
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = LocalWebClient()
            webChromeClient = LocalChromeClient()
            addJavascriptInterface(AndroidBridge(this@MainActivity), "androidBridge")
        }
        root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        installInsets()
        installBackHandling()
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        root.postDelayed({ splashKeep = false }, 420)
    }

    private fun installInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val imeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            val density = resources.displayMetrics.density
            topDp = bars.top / density
            bottomDp = if (imeVisible) 0f else bars.bottom / density
            v.setPadding(0, 0, 0, if (imeVisible) ime.bottom else 0)
            pushInsets()
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    private fun pushInsets() = js("window.__krInsets&&window.__krInsets($topDp,$bottomDp)")

    private fun installBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
            }
        })
    }

    override fun onStart() {
        super.onStart()
        js("window.__krAppState&&window.__krAppState(true)")
    }

    override fun onStop() {
        web.evaluateJavascript("window.__krAppState&&window.__krAppState(false)", null)
        super.onStop()
    }

    private fun setBarsDark(dark: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }

    private val authenticators
        get() = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK

    private fun bioReply(id: String, ok: Boolean, code: String) =
        js("window.__krBio&&window.__krBio(${JSONObject.quote(id)},$ok,${JSONObject.quote(code)})")

    private fun startBiometric(id: String, reason: String) {
        if (promptActive) { bioReply(id, false, "busy"); return }
        promptActive = true
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                promptActive = false; bioReply(id, true, "ok")
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                promptActive = false
                val code = when (errorCode) {
                    BiometricPrompt.ERROR_LOCKOUT, BiometricPrompt.ERROR_LOCKOUT_PERMANENT -> "biometryLockout"
                    BiometricPrompt.ERROR_USER_CANCELED, BiometricPrompt.ERROR_NEGATIVE_BUTTON, BiometricPrompt.ERROR_CANCELED -> "userCancel"
                    else -> "error"
                }
                bioReply(id, false, code)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Maktabah Manager")
            .setSubtitle("Unlock with biometrics")
            .setDescription(reason.ifBlank { "Verify your identity" })
            .setAllowedAuthenticators(authenticators)
            .setNegativeButtonText("Use PIN")
            .setConfirmationRequired(false)
            .build()
        try { prompt.authenticate(info) } catch (e: Exception) { promptActive = false; bioReply(id, false, "error") }
    }

    private fun saveToDownloads(name: String, mime: String, b64: String): Boolean {
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val safe = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "download" }
            val type = mime.ifBlank { "application/octet-stream" }
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe)
                    put(MediaStore.Downloads.MIME_TYPE, type)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                val out = contentResolver.openOutputStream(uri) ?: return false
                out.use { it.write(bytes) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return false
                dir.mkdirs()
                File(dir, safe).writeBytes(bytes)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private inner class LocalWebClient : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
            assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url
            if (url.host == "appassets.androidplatform.net") return false
            try { startActivity(Intent(Intent.ACTION_VIEW, url)) } catch (e: Exception) { }
            return true
        }
    }

    private inner class LocalChromeClient : WebChromeClient() {
        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: WebChromeClient.FileChooserParams?
        ): Boolean {
            if (filePathCallback == null || fileChooserParams == null) return false
            fileCallback?.onReceiveValue(null)
            fileCallback = filePathCallback
            return try {
                fileLauncher.launch(fileChooserParams.createIntent())
                true
            } catch (e: Exception) {
                fileCallback = null
                filePathCallback.onReceiveValue(null)
                false
            }
        }

        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setOnCancelListener { result?.cancel() }.show()
            return true
        }

        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
                .setOnCancelListener { result?.cancel() }.show()
            return true
        }
    }

    class AndroidBridge(private val activity: MainActivity) {
        @JavascriptInterface fun top(): Float = activity.topDp
        @JavascriptInterface fun bottom(): Float = activity.bottomDp
        @JavascriptInterface fun setDark(dark: Boolean) = activity.runOnUiThread { activity.setBarsDark(dark) }

        @JavascriptInterface
        fun checkBiometry(): String {
            val code = when (BiometricManager.from(activity).canAuthenticate(activity.authenticators)) {
                BiometricManager.BIOMETRIC_SUCCESS -> "ok"
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "biometryNotEnrolled"
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "biometryUnavailable"
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "noHardware"
                else -> "unavailable"
            }
            return "{\"isAvailable\":${code == "ok"},\"code\":\"$code\"}"
        }

        @JavascriptInterface
        fun authenticateAsync(id: String, reason: String) {
            activity.runOnUiThread { activity.startBiometric(id, reason) }
        }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String): Boolean = activity.saveToDownloads(name, mime, base64)
    }
}
