# KR Urdu Library Manager — Phase 1

## Multi-Class Architecture

Phase 1 adds `public.book_classes` as the many-to-many relationship between books and classes.

- One book can now have multiple classes.
- Existing `public.books.class_id` is retained temporarily as a legacy compatibility field.
- During Manager saves, `class_id` is kept equal to the first selected class so the current Library remains compatible until its own class-relationship update is performed.
- The real source of truth for Manager class assignment is `book_classes`.
- Existing `class_id` values were migrated into `book_classes`.
- Current live migration verification found no mismatches.
- `book_classes` has RLS and admin CRUD policies, plus public read access only for books whose status is `available` or `review`.

## Manager changes

- Add/Edit Book now uses a multi-select class picker.
- Catalogue shows all assigned classes.
- Import/export supports `classIds` while remaining compatible with legacy `classId` / `class_id` JSON.
- Manager loads `book_classes` and preserves the existing single `class_id` compatibility field.
- Duplicate/edit/save flows preserve multiple class assignments.

## Scope boundary

Phase 1 keeps the existing rule that at least one class is required. The final rule — class and category are both optional individually, but at least one of the two must be assigned — belongs to Phase 2.

No page-range data is stored.
