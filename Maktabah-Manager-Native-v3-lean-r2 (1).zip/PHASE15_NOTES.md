# KR Urdu Library Manager — Phase 15

## Nav: Tools → More
- Bottom-nav item renamed **More** with the ellipsis icon. Internal view key / URL hash stays `tools`, so saved state and links keep working.
- Titles/labels updated: header "More", screen hero "More", Classes/Categories back button "Back to More".

## Performance settings (More screen)
- New `js/perf.js`: modes **Auto / Full / Lite**, saved in `localStorage` (`krul_manager_perf_v1`), applied as `<html data-perf="full|lite">` before the app renders (also affects the login screen).
- **Auto** picks Lite when: Data Saver is on, device memory <= 2 GB, or <= 4 CPU cores (cores rule skipped on iPhone/iPad). Browsers that expose none of these signals (e.g. Safari) get Full.
- **Lite** turns off: backdrop blur, transitions/animations (spinner kept), heavy shadows, the aurora gradient (flat gradient instead), decorative ornaments, smooth scrolling. Long lists (`.book-card`, `.tx-row`, `.recent-row`) use `content-visibility:auto`. Cover images load with `loading="lazy"` in every mode.
- Switching applies instantly; an info line explains what Auto currently resolved to and why.

## Glass login
- Same glass language as the rest of the app: glass card, gold-bordered brand tile, icon inputs, show/hide password, pill primary button, light/dark toggle (theme persists from the manager).
- Errors / "Signed out" notices appear inline (no full re-render, so the typed email is kept). Network failures during sign-in now show a message instead of an unhandled error.
- Sign-in logic (Supabase `signInWithPassword`, `is_admin` check) is unchanged.

No database change.
