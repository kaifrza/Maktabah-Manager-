# Phase 19 — Categories screen polish (UI/UX only)

Screen-by-screen production polish. Build/APK code (workflow, Gradle, Kotlin, manifest) untouched.

## Categories (and Classes, because they share one renderer)
- List first: the create/edit form no longer pushes the list down the page.
- Create/edit form is now a bottom sheet (centered dialog on wide screens): New button, row tap, Esc / backdrop / X / Cancel to close, Enter to save, page scroll locked while open.
- Compact summary strip (Total / Active / Inactive / Tagged + active-share bar) instead of four large cards.
- Search + All/Active/Inactive filter chips (shown when there are 5 or more items), with a "no match" state.
- Compact rows: whole row opens edit, inline switch for activate/deactivate (existing confirm dialogs kept), long Urdu names wrap to 2 lines instead of being cut.
- Category ID auto-fills from the English name while creating (still editable).
- Better empty state with a Create button; validation messages appear inside the sheet.
- Fixed horizontal overflow on narrow (<=340px) screens.

## Files changed
- manager/js/manager.js  (renderTaxonomy rewritten; small hooks in saveCategory/saveClass, validation helpers, setView)
- manager/css/manager.css (old taxonomy row styles replaced, Phase 19 styles appended)

# Phase 20 — Catalogue screen polish (UI/UX only)
- Removed the big hero card; compact toolbar: search (with clear) + Add button.
- Status chips now show counts (All / Available / Needs review / Unavailable); type chips + Sort (Newest, Oldest, Title, ID).
- Search also matches keywords and class names; "Clear filters" appears only when a filter is active; result count line ("3 of 12 books").
- Filters/search/sort are remembered when the list re-renders (after save, copy, delete, refresh).
- Compact book cards (~40% shorter): tap card = Edit; "⋯" opens an action sheet (Edit, Preview, Duplicate, Delete). Urdu titles left-aligned like the rest of the UI, class shown by English name (+N for multiple).
- Loading skeleton on first load (no more false "No books yet" flash); better empty / no-match states.
- Delete now uses the app's confirm dialog instead of the browser confirm().
- Files changed: manager/js/manager.js, manager/css/manager.css
