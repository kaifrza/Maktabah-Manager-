# KR Urdu Library Manager — Phase 2

## Scope
Class and Category are now independently optional, but a book must belong to at least one of them.

Allowed:
- Class only
- Category only
- One or more classes + one or more categories

Blocked:
- No classes + no categories

## Changes
- Add/Edit form labels explicitly mark Classes and Categories as optional.
- Class/category helper text no longer says at least one class is required.
- `validateRecord()` enforces the combined rule: at least one class OR at least one category.
- Existing multi-class and multi-category persistence is preserved.
- Import validation uses the same rule because imports flow through `validateRecord()`.
- No Supabase schema change was required in this phase.

## Validation
- Existing Phase 1 data is untouched.
- Phase 1 `book_classes` architecture is preserved.
