# KR Urdu Library Manager — Phase 16 (fixes)

## 1. Add screen layout broken (root cause + fix)
- Cause: the hidden native `<select class="seg-native">` elements behind the segmented controls (Book type, Source type)
  matched `.add-v2 .field select{width:100%;min-height:54px;padding…}`, which has higher specificity than
  `.seg-native{width:1px}`. They were absolutely positioned but 100% wide, so they stuck out of the card and made
  the whole page scroll sideways (35px on phones, ~285px on desktop), which shifted/clipped the layout.
- Fix: `.seg-native` geometry is now pinned (`!important`, 1x1px, clipped) and `.add-v2 .field` is `position:relative`.
- Verified in headless Chromium at 320 / 360 / 390 / 768 / 1280px: document width == viewport width.
  All six screens also checked at 360px in Full and Lite: no horizontal overflow.

## 2. Lite mode confirmation dialog
- Cause: `.dialog` used a hard-coded translucent background that relied on backdrop blur. Lite mode removes the blur,
  so the page behind showed through.
- Fix: in Lite the dialog is solid (light and dark), the overlay is darker, and the sticky header / bottom nav /
  sub-header are solid as well (they had the same ghosting at 94% opacity).

## 3. Sign-out icon
- Header button and the confirmation dialog now use a power icon (`fa-power-off`) instead of the right-arrow icon.
- The header button is tinted red (light and dark) so it is not confused with refresh / theme.
