# KR Urdu Library Manager — Phase 5

## Source Management

Phase 5 hardens the book-source workflow around the two real catalogue sources used by KR Urdu Library: Internet Archive and public Google Drive.

### Added
- Source Type selector: Auto detect, Internet Archive, Google Drive, Direct PDF.
- Source/item URL field for Archive item pages, Drive file pages, or direct PDF URLs.
- One-click source resolution.
- Internet Archive metadata resolution remains supported and now explicitly marks the source type.
- Google Drive public file URL detection and normalization to a direct download URL.
- Source validation button with HTTP reachability check and source-host consistency checks.
- Source status indicator in the form.
- Source type is preserved in local/imported manager records and derived safely from existing Supabase fields for older records.
- Existing Supabase schema is unchanged. `books.source_name`, `books.source_page_url`, and `books.pdf_url` remain the persisted source fields.
- Existing JSON import/export remains backward compatible.

### Safety / compatibility
- No service-role or privileged key added to the Manager.
- No database migration required.
- Existing Archive PDF URLs continue to work.
- Existing direct PDF records continue to work.
- Google Drive validation warns that the file must be public for the Library reader/download flow.
- Existing multi-class, optional class/category, Category Manager, Class Manager, cover pipeline, CRUD and Data Tools are preserved.

## Validation
- `node --check manager/js/manager.js`: PASS
- HTML parser validation: PASS
- ZIP integrity: PASS
- No `service_role`, secret key, `eval`, `new Function`, or `javascript:` URL introduced.
