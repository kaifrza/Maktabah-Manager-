# Maktabah Manager — Phase 17 (Android app packaging)

## Inside this zip (the workflow adds nothing)
- `branding/` — premium app icon (aurora + emerald glass tile + gold book) and splash screen (light/dark). Replace the PNGs to change the look; keep the file names.
- `manager/applock.js` — **optional** local 6-digit App Lock + biometric unlock.
  - OFF by default: a fresh install shows no lock screen.
  - Turn on / change PIN / lock now / biometric on-off / turn off: **More → App lock**.
  - PIN is stored only on the device (salted SHA-256, localStorage). No Supabase involvement.
  - Locks on app start and after >10s in background (only when enabled). 5 wrong tries → timed lockout.
  - Lock screen uses the app's glass design (aurora, gold-bordered brand tile, light/dark theme, Lite mode aware). All text in English.
- App name: **Maktabah Manager**.

## Workflow
`.github/workflows/build-apk.yml` only: picks the latest zip, extracts it, wraps `manager/` with Capacitor, generates icons/splash from `branding/`, builds the APK.

No database change.
