# Maktabah Manager - Phase 18 (icon, splash, lock screen, biometric, status bar)

## Branding (`branding/`)
- New icon: emerald full-bleed background with a faint star lattice, gold open book and an 8-point star. Adaptive-icon safe (foreground = symbol only, background = plain art).
- New splash (light + dark): app tile, "Maktabah Manager", "KR URDU LIBRARY". Text sized to survive tall-phone cropping.

## Lock screen (`manager/applock.js`)
- New glass design with the app logo, shake on a wrong PIN, attempts-left hint, smooth fade on unlock.
- Timed lockout now runs live: a countdown ring ticks every second, keypad is disabled meanwhile, survives app restart, and re-enables itself when the time ends (30s, 60s, 2m, 4m, 5m cap).
- PIN hash upgraded to PBKDF2 (old PINs keep working and upgrade silently on the next correct unlock).

## Biometric
- The workflow now installs the biometric plugin (version matched to Capacitor) and adds the USE_BIOMETRIC permission; the build fails if the plugin is missing.
- Asks for fingerprint/face automatically when the app opens or returns after a break; fingerprint key on the keypad; PIN is always the fallback.
- After creating a PIN the app offers "Enable biometric". More > App lock shows why biometrics are unavailable (none enrolled / not supported).

## Status bar gap
- Native layer (MainActivity) draws edge-to-edge with a transparent status bar and gives the page the real inset sizes (`--sat`, `--sab`).
- In the APK the header now starts at the very top and fills the status bar area (no strip above it). Sub-screen headers do the same. Status bar icon colour follows the light/dark theme. Keyboard resizing handled.
- Browser use is unchanged.

## Workflow
`.github/workflows/build-apk.yml`: picks the newest zip, builds with Capacitor 7, generates icons/splash, patches native files, keeps one signing key in cache, verifies the APK, uploads an artifact and publishes a GitHub Release (direct download on phone). Optional repo variable `APP_ID` overrides the package id.

## Fix 1
- Biometric detection no longer depends on a single flag; it re-checks when More > App lock opens and also falls back to Capacitor.Plugins.
- More > App lock now shows a "status" code under the buttons whenever biometrics are not offered, so the cause is visible.
