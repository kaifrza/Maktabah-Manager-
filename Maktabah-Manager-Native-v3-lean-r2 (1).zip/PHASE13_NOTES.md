# KR Urdu Library Manager — Phase 13

## Glass Tools screen
- `renderTools()` rebuilt in the same glassmorphism language as Home, Add and Catalogue.
- New scoped block `.tools-v2` (CSS "Phase 13") reuses the existing glass tokens (`--gl-*`), `.glass-card`, `.quick-action`, `.pill-btn`, and `.tone-*` colours, so light/dark themes and the blur fallback work automatically.
- Layout: glass hero (Maintenance / Data Tools + live book count) → Organise library (Classes, Categories) → 4 glass tool cards (Backup, Import, Record preview, Local safety cache) → Manager rules.
- All element ids (`export`, `import`, `importFile`, `preview`, `clearLocal`) and `data-go` navigation are unchanged, so existing handlers keep working.
- "Clear local cache" now uses the glass `confirmDialog` instead of the native browser `confirm()`.
- No database or schema change.
