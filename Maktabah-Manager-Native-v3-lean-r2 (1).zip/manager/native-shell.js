/* APK shell: real status/navigation bar insets from the native side,
   app-mode flag for CSS, and status-bar icon colour that follows the theme. */
(function () {
  'use strict';
  var cap = window.Capacitor, bridge = window.KRInsets || window.androidBridge;
  var isApp = !!(bridge || (cap && cap.isNativePlatform && cap.isNativePlatform()));
  if (!isApp) return;
  var root = document.documentElement;
  root.classList.add('is-app');

  function apply(t, b) {
    t = Number(t) || 0; b = Number(b) || 0;
    root.style.setProperty('--sat', t + 'px');
    root.style.setProperty('--sab', b + 'px');
  }
  window.__krInsets = apply;
  try { if (bridge) apply(bridge.top(), bridge.bottom()); } catch (e) {}

  function bars() {
    var dark = !!(document.body && document.body.classList.contains('dark'));
    try { if (bridge) bridge.setDark(dark); } catch (e) {}
  }
  function watch() {
    bars();
    new MutationObserver(bars).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  }
  if (document.body) watch(); else document.addEventListener('DOMContentLoaded', watch);

  /* Blob/data downloads (JSON export, cover download) -> phone Downloads folder */
  function toast(msg) {
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:calc(var(--sab,0px) + 96px);z-index:2147483646;max-width:86vw;padding:12px 18px;border-radius:18px;background:rgba(16,38,30,.92);color:#fff;font:600 .86rem Manrope,system-ui,sans-serif;box-shadow:0 12px 30px rgba(0,0,0,.3)';
    document.body.appendChild(t);
    setTimeout(function () { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(function () { t.remove(); }, 320); }, 2400);
  }
  function sendFile(href, name) {
    fetch(href).then(function (r) { return r.blob(); }).then(function (blob) {
      var fr = new FileReader();
      fr.onload = function () {
        var ok = false;
        try { ok = bridge.saveFile(name || 'download', blob.type || 'application/octet-stream', String(fr.result).split(',')[1] || ''); } catch (e) {}
        toast(ok ? 'Saved to Downloads: ' + (name || 'file') : 'Could not save the file.');
      };
      fr.readAsDataURL(blob);
    }).catch(function () { toast('Could not save the file.'); });
  }
  if (bridge && bridge.saveFile) {
    var origClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
      if (this.hasAttribute('download') && /^(blob:|data:)/.test(this.href)) { sendFile(this.href, this.getAttribute('download')); return; }
      return origClick.apply(this, arguments);
    };
  }
  window.addEventListener('orientationchange', function () {
    setTimeout(function () { try { if (bridge) apply(bridge.top(), bridge.bottom()); } catch (e) {} }, 350);
  });
})();
