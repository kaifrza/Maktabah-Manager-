import { supabase } from './lib/supabase.js';

const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const root = document.querySelector('#manager');

const THEME_KEY = 'krul_manager_theme';
const SIGN_IN_LABEL = '<i class="fa-solid fa-right-to-bracket"></i> Sign In';

export function renderLogin(message = '', type = 'error') {
  // keep the saved light/dark theme on the login screen too
  document.body.classList.toggle('dark', localStorage.getItem(THEME_KEY) === 'dark');
  document.body.classList.remove('focus-mode');
  const msgHtml = (text, kind) => text
    ? `<div class="auth-message ${kind === 'success' ? 'success' : 'error'}" role="${kind === 'success' ? 'status' : 'alert'}"><i class="fa-solid ${kind === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation'}" aria-hidden="true"></i><span>${esc(text)}</span></div>`
    : '';

  root.innerHTML = `<main class="auth-shell"><section class="auth-card" aria-labelledby="loginTitle">
    <button type="button" class="auth-theme" id="authTheme" aria-label="Toggle theme"><i class="fa-solid fa-circle-half-stroke"></i></button>
    <div class="auth-brand"><i class="fa-solid fa-book-open"></i></div>
    <span class="auth-kicker">Manager Sign In</span>
    <h1 id="loginTitle">KR Urdu Library</h1>
    <p class="auth-sub">Sign in to manage the library catalogue.</p>
    <div id="authMsg" aria-live="polite">${msgHtml(message, type)}</div>
    <form id="loginForm" novalidate>
      <div class="field"><label for="loginEmail">Email</label><div class="auth-input"><i class="fa-solid fa-envelope" aria-hidden="true"></i><input id="loginEmail" type="email" inputmode="email" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="admin@example.com" required></div></div>
      <div class="field"><label for="loginPassword">Password</label><div class="auth-input"><i class="fa-solid fa-lock" aria-hidden="true"></i><input id="loginPassword" type="password" autocomplete="current-password" placeholder="Your password" required><button type="button" class="auth-eye" id="togglePassword" aria-label="Show password"><i class="fa-solid fa-eye"></i></button></div></div>
      <button class="pill-btn primary auth-submit" id="loginSubmit" type="submit">${SIGN_IN_LABEL}</button>
    </form>
    <p class="auth-note"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Private Manager · Authorized administrators only</p>
  </section></main>`;

  const $ = s => document.querySelector(s);
  const showMsg = (text, kind = 'error') => { $('#authMsg').innerHTML = msgHtml(text, kind); };

  $('#authTheme')?.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    localStorage.setItem(THEME_KEY, document.body.classList.contains('dark') ? 'dark' : 'light');
  });

  $('#togglePassword')?.addEventListener('click', () => {
    const input = $('#loginPassword');
    const icon = $('#togglePassword i');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    icon.className = show ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
    $('#togglePassword').setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  });

  $('#loginForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const emailEl = $('#loginEmail'), passEl = $('#loginPassword'), button = $('#loginSubmit');
    const email = emailEl.value.trim(), password = passEl.value;
    if (!email || !password) {
      showMsg('Email and password are required.');
      (email ? passEl : emailEl).focus();
      return;
    }
    const setBusy = busy => {
      button.disabled = busy;
      button.innerHTML = busy ? '<i class="fa-solid fa-spinner fa-spin"></i> Signing in…' : SIGN_IN_LABEL;
    };
    setBusy(true); showMsg('');
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) { showMsg(error.message || 'Sign in failed.'); setBusy(false); passEl.focus(); return; }
    } catch {
      showMsg('Network problem. Check your connection and try again.');
      setBusy(false);
      return;
    }
    await bootManager();
  });
}

export async function guardManager() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) { renderLogin(); return false; }
  const { data, error } = await supabase.rpc('is_admin');
  if (error || data !== true) {
    await supabase.auth.signOut();
    renderLogin('This account is authenticated but is not authorized as a Manager administrator.');
    return false;
  }
  return true;
}

export async function bootManager() {
  if (await guardManager()) {
    const { initManager } = await import('./manager.js');
    initManager();
    return true;
  }
  return false;
}

export async function signOutManager() {
  await supabase.auth.signOut();
  renderLogin('Signed out successfully.', 'success');
}
