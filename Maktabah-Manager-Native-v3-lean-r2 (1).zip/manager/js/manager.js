import { supabase } from "./lib/supabase.js";
import { signOutManager } from "./auth.js";
import { getPerfMode, setPerfMode, detectDevice, resolvePerf, isLite } from "./perf.js";

const $ = (s, root = document) => root.querySelector(s);
const manager = $("#manager");
const STORAGE_KEY = "krul_manager_catalogue_v2";
const VIEW_KEY = "krul_manager_view_v1";
let books = [], classes = [], categories = [];
let editingId = null;
let editingCategoryId = null;
let editingClassId = null;
let selectedCover = { path: "", blob: null, fileName: "" };
let formSnapshot = "";
let loading = false;
let dataLoaded = false;
const catUi = { q: "", status: "all", type: "all", sort: "newest" };

const esc = (v = "") => String(v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const slug = v => String(v || "book").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,50);
const isHttpUrl = v => /^https?:\/\//i.test(String(v || "").trim());
const normalizeUrl = v => { try { const u = new URL(String(v).trim()); u.hash=""; u.hostname=u.hostname.toLowerCase(); if((u.protocol==="https:"&&u.port==="443")||(u.protocol==="http:"&&u.port==="80"))u.port=""; return u.href.replace(/\/$/,""); } catch { return String(v||"").trim(); } };
const csv = v => [...new Set(String(v||"").split(",").map(x=>x.trim()).filter(Boolean))];
const today = () => new Date().toISOString().slice(0,10);

function notify(message,type="info") { const el=$("#toast"); if(!el)return; el.className=`toast ${type}`; el.innerHTML=message; el.hidden=false; clearTimeout(notify.timer); notify.timer=setTimeout(()=>el.hidden=true,4200); }
function setSyncState(type,text){ const el=$("#syncState"); if(el){el.className=`sync-state ${type}`; el.innerHTML=`<i class="fa-solid fa-circle"></i> ${esc(text)}`;} }
function icon(name){ return `<i class="fa-solid ${name}" aria-hidden="true"></i>`; }

function render(){
  manager.innerHTML=`<div class="manager-app">
    <main class="main-area">
      <header class="topbar">
        <div class="top-brand"><span class="brand-mark">${icon("fa-book-open")}</span><div class="top-title"><span class="page-kicker" id="pageKicker">Workspace</span><h1 id="pageTitle">Dashboard</h1></div></div>
        <div class="top-actions"><span id="syncState" class="sync-state busy">${icon("fa-circle")} Connecting…</span><button class="hbtn" id="refresh" title="Refresh catalogue" aria-label="Refresh catalogue">${icon("fa-arrows-rotate")}</button><button class="hbtn" id="theme" title="Toggle theme" aria-label="Toggle theme">${icon("fa-circle-half-stroke")}</button><button class="hbtn" id="signOut" title="Sign out" aria-label="Sign out">${icon("fa-power-off")}</button></div>
      </header>
      <div id="toast" class="toast" hidden></div>
      <div class="views">
        <section data-view-section="dashboard" class="view"><div id="dashboardContent"></div></section>
        <section data-view-section="add" class="view"><div id="addContent"></div></section>
        <section data-view-section="catalogue" class="view"><div id="catalogueContent"></div></section>
        <section data-view-section="categories" class="view"><div id="categoriesContent"></div></section>
        <section data-view-section="classes" class="view"><div id="classesContent"></div></section>
        <section data-view-section="tools" class="view"><div id="toolsContent"></div></section>
      </div>
    </main>
    <nav class="mobile-nav" aria-label="Mobile navigation">
      <button class="nav-item" data-view="dashboard">${icon("fa-gauge-high")}<span>Home</span></button>
      <button class="nav-item" data-view="add">${icon("fa-square-plus")}<span>Add</span></button>
      <button class="nav-item" data-view="catalogue">${icon("fa-book-open-reader")}<span>Catalogue</span><b id="navBookCount">0</b></button>
      <button class="nav-item" data-view="tools">${icon("fa-ellipsis")}<span>More</span></button>
    </nav>
    <div class="modal-backdrop" id="modal" hidden></div>
  </div>`;
  bindGlobalEvents();
  renderAllViews();
  initNavigation();
  loadData();
}

function renderAllViews(){ renderDashboard(); renderAdd(); renderCatalogue(); renderCategories(); renderClasses(); renderTools(); updateNavigationMeta(); }
function updateNavigationMeta(){ const c=$("#navBookCount"); if(c)c.textContent=books.length; const cc=$("#navCategoryCount"); if(cc)cc.textContent=categories.filter(x=>x.isActive).length; const cl=$("#navClassCount"); if(cl)cl.textContent=classes.filter(x=>x.isActive).length; }
function renderDashboard(){
  const total=books.length, available=books.filter(b=>b.status==="available").length, review=books.filter(b=>b.status==="review").length, covers=books.filter(b=>b.cover).length;
  const pct=n=>total?Math.round(n/total*100):0;
  const recent=[...books].sort((a,b)=>String(b.addedAt).localeCompare(String(a.addedAt))).slice(0,6);
  const stat=(tone,ic,val,label,share)=>`<div class="home-stat ${tone}"><span class="hs-ico">${icon(ic)}</span><div class="hs-body"><strong>${val}</strong><span>${label}</span></div>${share===null?"":`<i class="meter" aria-hidden="true"><b style="width:${share}%"></b></i>`}</div>`;
  const qa=(go,ic,title,sub)=>`<button class="quick-action" data-go="${go}"><span class="qa-ico">${icon(ic)}</span><span class="qa-text"><strong>${title}</strong><small>${sub}</small></span>${icon("fa-chevron-right")}</button>`;
  $("#dashboardContent").innerHTML=`<div class="home-v2">
  <section class="home-hero">
    <div class="hh-copy"><h2>Catalogue workspace</h2><p>Add, review and maintain books in a few taps.</p></div>
    <button class="pill-btn primary hh-cta" data-go="add" type="button">${icon("fa-plus")} Add a new book</button>
  </section>
  <div class="home-stats">
    ${stat("tone-a","fa-book",total,"Total books",null)}
    ${stat("tone-b","fa-circle-check",available,"Available",pct(available))}
    ${stat("tone-c","fa-triangle-exclamation",review,"Needs review",pct(review))}
    ${stat("tone-d","fa-image",covers,"With covers",pct(covers))}
  </div>
  <div class="home-grid">
    <section class="glass-card">
      <header class="glass-head"><div><h3>Recent books</h3><p>Latest catalogue records</p></div><button class="pill-btn sm" data-go="catalogue" type="button">View all ${icon("fa-arrow-right")}</button></header>
      ${recent.length?`<div class="recent-list">${recent.map(b=>`<button class="recent-row" data-edit="${esc(b.id)}"><span class="recent-cover">${b.cover?`<img src="${esc(b.cover)}" alt="" loading="lazy" decoding="async">`:icon("fa-book")}</span><span class="recent-info"><strong>${esc(b.title||"Untitled")}</strong><small>${esc(b.id)} · ${esc(b.author||"No author")}</small></span><span class="status ${esc(b.status)}">${esc(statusLabel(b.status))}</span>${icon("fa-chevron-right")}</button>`).join("")}</div>`:`<div class="empty"><div>${icon("fa-book")}</div><strong>No books yet</strong><p>Add your first catalogue record.</p></div>`}
    </section>
    <section class="glass-card">
      <header class="glass-head"><div><h3>Quick actions</h3><p>Common manager tasks</p></div></header>
      <div class="qa-list">
        ${qa("add","fa-square-plus","Add Book","Create a new record")}
        ${qa("catalogue","fa-book-open-reader","Catalogue","Search and edit books")}
        ${qa("classes","fa-layer-group","Classes","Levels and grouping")}
        ${qa("categories","fa-tags","Categories","Topics and subjects")}
        ${qa("tools","fa-file-export","Backup / Import","Move catalogue data")}
      </div>
    </section>
  </div>
  </div>`;
}

function renderAdd(){
  $("#addContent").innerHTML=`<div class="add-v2">
  <section class="add-hero">
    <div class="hero-top">
      <div class="hero-copy"><h2 id="formTitle">${editingId?`Edit book · ${esc(editingId)}`:"Add a book"}</h2><p>Four short steps. A title and a PDF link are all you need.</p></div>
      <button class="hero-new" id="formNew" type="button">${icon("fa-plus")} <span>New</span></button>
    </div>
    <div class="draft-card"><span class="draft-icon">${icon("fa-book")}</span><div class="draft-text"><strong id="draftTitle" dir="auto">Untitled book</strong><small id="draftMeta">Start typing a title to see it here</small></div></div>
    <div class="stepper">
      <button type="button" class="step active" data-scroll-to="sectionBook"><span class="step-ico">${icon("fa-pen-nib")}</span><b>Book</b></button>
      <button type="button" class="step" data-scroll-to="sectionSource"><span class="step-ico">${icon("fa-link")}</span><b>Source</b></button>
      <button type="button" class="step" data-scroll-to="sectionCover"><span class="step-ico">${icon("fa-image")}</span><b>Cover</b></button>
      <button type="button" class="step" data-scroll-to="sectionFinish"><span class="step-ico">${icon("fa-circle-check")}</span><b>Save</b></button>
    </div>
  </section>

  <section class="add-card" id="sectionBook">
    <header class="card-head"><span class="card-ico">${icon("fa-pen-nib")}</span><div><h3>Book details</h3><p>Title, author, type and where it belongs</p></div></header>
    <div class="fields">
      <div class="field full"><label for="title">Title <em>*</em></label><input id="title" dir="auto" autocomplete="off" placeholder="مثلاً: فَنِّ مضمون نگاری"></div>
      <div class="field"><label for="titleEn">English / Roman title</label><input id="titleEn" autocomplete="off" placeholder="Fann-e-Mazmoon Nigari"></div>
      <div class="field"><label for="author">Author</label><input id="author" placeholder="Author name"></div>
      <div class="field full"><label>Book type <em>*</em></label>
        <select id="type" class="seg-native" tabindex="-1" aria-hidden="true"><option value="matn">Matn — متن</option><option value="sharah">Commentary — شرح</option></select>
        <div class="seg seg-2" data-seg-for="type"><button type="button" data-val="matn"><b>Matn</b><small>متن</small></button><button type="button" data-val="sharah"><b>Commentary</b><small>شرح</small></button></div>
      </div>
      <div class="field full"><label>Classes <span class="optional-label">Optional</span></label><div id="classPicker" class="category-picker"></div><small class="muted" id="classHint"></small></div>
      <div class="field full"><label>Categories <span class="optional-label">Optional</span></label><div id="categoryPicker" class="category-picker"></div><small class="muted" id="categoryHint"></small></div>
      <div class="field full"><label for="description">Short description</label><textarea id="description" placeholder="A short description for readers…"></textarea></div>
      <div class="field full"><label for="keywords">Search keywords</label><input id="keywords" placeholder="Urdu + Roman terms, comma separated"></div>
    </div>
  </section>

  <section class="add-card" id="sectionSource">
    <header class="card-head"><span class="card-ico">${icon("fa-link")}</span><div><h3>PDF source</h3><p>Paste a link, resolve it, then validate</p></div><span id="sourceStatus" class="status idle">Not checked</span></header>
    <div class="fields">
      <div class="field full"><label>Source type <em>*</em></label>
        <select id="sourceType" class="seg-native" tabindex="-1" aria-hidden="true"><option value="auto">Auto detect</option><option value="archive">Internet Archive</option><option value="drive">Google Drive</option><option value="direct">Direct PDF</option></select>
        <div class="seg seg-4" data-seg-for="sourceType"><button type="button" data-val="auto">${icon("fa-wand-magic-sparkles")}<b>Auto</b></button><button type="button" data-val="archive">${icon("fa-box-archive")}<b>Archive</b></button><button type="button" data-val="drive">${icon("fa-cloud")}<b>Drive</b></button><button type="button" data-val="direct">${icon("fa-file-pdf")}<b>Direct</b></button></div>
      </div>
      <div class="field full"><label for="sourcePage">Source / item URL</label><input id="sourcePage" type="url" placeholder="https://archive.org/details/… or a Drive file link"><small class="muted">An Archive item page, a public Drive file page, or a direct PDF link.</small></div>
      <div class="field full"><label for="pdf">Direct PDF URL <em>*</em></label><input id="pdf" type="url" placeholder="https://…/book.pdf"></div>
    </div>
    <div class="btn-row"><button class="pill-btn soft" id="resolveSource" type="button">${icon("fa-wand-magic-sparkles")} Resolve source</button><button class="pill-btn" id="testSource" type="button">${icon("fa-circle-check")} Validate</button></div>
    <details class="advanced"><summary>${icon("fa-sliders")} <span>More details</span></summary><div class="advanced-grid"><div class="field"><label for="sourceName">Source name</label><input id="sourceName" placeholder="Internet Archive / Google Drive"></div><div class="field"><label for="pages">Pages</label><input id="pages" type="number" min="1" step="1" placeholder="Auto / optional"></div><div class="field"><label for="status">Availability</label><select id="status"><option value="available">Available</option><option value="review">Needs review</option><option value="unavailable">Unavailable</option></select></div></div></details>
  </section>

  <section class="add-card" id="sectionCover">
    <header class="card-head"><span class="card-ico">${icon("fa-image")}</span><div><h3>Cover</h3><p>Optional. From a PDF page or an image</p></div><span id="coverStatus" class="status idle">No cover generated</span></header>
    <div class="cover-layout">
      <div class="cover-preview" id="coverPreview"><div>${icon("fa-image")}<span>Cover preview</span></div></div>
      <div class="cover-controls">
        <input id="coverFile" class="dz-input" type="file" accept="application/pdf,image/png,image/jpeg,image/webp">
        <label class="dropzone" for="coverFile"><span class="dz-ico">${icon("fa-cloud-arrow-up")}</span><span class="dz-text"><strong id="dzName">Choose a PDF or image</strong><small>PNG, JPG or WebP. For a PDF, one page is extracted.</small></span></label>
        <div class="fields two"><div class="field"><label for="coverPage">PDF page</label><input id="coverPage" type="number" min="1" value="1"></div><div class="field"><label for="coverFit">Output</label><select id="coverFit"><option value="cover">Portrait cover</option><option value="contain">Full page</option></select></div></div>
        <div class="btn-row"><button class="pill-btn primary" id="generateCover" type="button">${icon("fa-wand-magic-sparkles")} Generate &amp; upload</button><button class="pill-btn" id="downloadCover" type="button" disabled>${icon("fa-download")} Backup</button></div>
        <small class="muted">Uploads to the covers bucket in Supabase. Backup saves a local copy if the upload fails.</small>
      </div>
    </div>
  </section>

  <section class="add-card finish-card" id="sectionFinish">
    <header class="card-head"><span class="card-ico">${icon("fa-circle-check")}</span><div><h3>Review &amp; save</h3><p>Validate if you like, then save to the catalogue</p></div></header>
    <button class="cta" id="saveBook" type="button">${icon("fa-floppy-disk")} <span>${editingId?"Update Book":"Save Book"}</span></button>
    <div class="btn-row keep2"><button class="pill-btn" id="saveNew" type="button">${icon("fa-floppy-disk")} Save &amp; New</button><button class="pill-btn" id="validate" type="button">${icon("fa-circle-check")} Validate</button></div>
    <div id="result" class="result muted"></div>
  </section>
  </div>`;
  renderClassPicker([]); renderCategoryPicker(getSelectedCategoriesSafe()); bindFormEvents(); initAddUi();
}

function updateAddUi(){
  const g=id=>document.getElementById(id), dt=g("draftTitle"); if(!dt)return;
  const v=id=>(g(id)?.value||"").trim(), title=v("title"), en=v("titleEn"), author=v("author");
  dt.textContent=title||en||"Untitled book";
  const meta=[author,typeLabel(g("type")?.value||"matn")].filter(Boolean).join(" · ");
  g("draftMeta").textContent=(title||en||author)?meta:"Start typing a title to see it here";
  const done={sectionBook:!!(title||en),sectionSource:isHttpUrl(v("pdf")),sectionCover:!!(selectedCover.path||selectedCover.blob||g("coverFile")?.files?.length),sectionFinish:false};
  document.querySelectorAll(".stepper [data-scroll-to]").forEach(x=>x.classList.toggle("done",!!done[x.dataset.scrollTo]));
}
function initAddUi(){
  const root=document.querySelector(".add-v2"); if(!root)return;
  const sync=()=>root.querySelectorAll(".seg[data-seg-for]").forEach(seg=>{const sel=document.getElementById(seg.dataset.segFor);if(!sel)return;seg.querySelectorAll("button").forEach(b=>{const on=b.dataset.val===sel.value;b.classList.toggle("on",on);b.setAttribute("aria-pressed",on?"true":"false");});});
  const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,"value");
  root.querySelectorAll(".seg-native").forEach(sel=>Object.defineProperty(sel,"value",{configurable:true,get(){return d.get.call(this);},set(val){d.set.call(this,val);sync();updateAddUi();}}));
  root.querySelectorAll(".seg button").forEach(b=>b.addEventListener("click",()=>{const sel=document.getElementById(b.parentElement.dataset.segFor);if(!sel)return;sel.value=b.dataset.val;sel.dispatchEvent(new Event("input",{bubbles:true}));sel.dispatchEvent(new Event("change",{bubbles:true}));}));
  root.addEventListener("input",updateAddUi);
  root.addEventListener("change",e=>{if(e.target.id==="coverFile"){const f=e.target.files[0],n=document.getElementById("dzName");if(n)n.textContent=f?f.name:"Choose a PDF or image";}updateAddUi();});
  root.addEventListener("click",()=>setTimeout(updateAddUi,0));
  ["coverPreview","coverStatus"].forEach(id=>{const el=document.getElementById(id);if(el)new MutationObserver(updateAddUi).observe(el,{childList:true,characterData:true,subtree:true,attributes:true});});
  sync(); updateAddUi();
}

/* ---- Catalogue (v3): compact toolbar, status chips with counts, sort, compact cards, action sheet ---- */
function bookClassNames(b){return (b.classIds||[]).map(id=>{const c=classes.find(x=>x.id===id);return c?(c.nameEn||c.name||id):id;});}
function bookClassText(b){const n=bookClassNames(b);return n.length?(n.length>1?`${n[0]} +${n.length-1}`:n[0]):"";}
function renderCatalogue(){
  const cnt=s=>s==="all"?books.length:books.filter(b=>b.status===s).length;
  const seg=(items,withCount)=>items.map(([v,l])=>`<button type="button" data-val="${v}">${l}${withCount?` <b>${cnt(v)}</b>`:""}</button>`).join("");
  $("#catalogueContent").innerHTML=`<div class="cat-v2 cv3">
  <section class="ct-bar">
    <div class="ct-row">
      <label class="ct-search"><span class="cs-ico">${icon("fa-magnifying-glass")}</span><input id="catalogSearch" type="search" placeholder="Search title, author, ID, source…" autocomplete="off" enterkeyhint="search" aria-label="Search catalogue" value="${esc(catUi.q)}"><button class="ct-clear" type="button" id="catalogSearchClear" aria-label="Clear search" ${catUi.q?"":"hidden"}>${icon("fa-xmark")}</button></label>
      <button class="ct-add" type="button" data-go="add" aria-label="Add book">${icon("fa-plus")}<span>Add book</span></button>
    </div>
    <select id="catalogFilter" class="seg-native" tabindex="-1" aria-hidden="true"><option value="all">All statuses</option><option value="available">Available</option><option value="review">Needs review</option><option value="unavailable">Unavailable</option></select>
    <select id="catalogType" class="seg-native" tabindex="-1" aria-hidden="true"><option value="all">All types</option><option value="matn">Matn</option><option value="sharah">Commentary</option></select>
    <div class="chip-scroll" data-seg-for="catalogFilter" role="group" aria-label="Filter by status">${seg([["all","All"],["available","Available"],["review","Needs review"],["unavailable","Unavailable"]],true)}</div>
    <div class="ct-row ct-row2">
      <div class="chip-scroll sm" data-seg-for="catalogType" role="group" aria-label="Filter by type">${seg([["all","All types"],["matn","Matn"],["sharah","Commentary"]],false)}</div>
      <label class="ct-sort">${icon("fa-arrow-down-wide-short")}<select id="catalogSort" aria-label="Sort books"><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="title">Title</option><option value="id">ID</option></select></label>
    </div>
  </section>
  <div class="ct-count"><span id="countBadge" aria-live="polite">0 books</span><button class="text-btn" id="clearFilters" type="button" hidden>${icon("fa-rotate-left")} Clear filters</button></div>
  <div class="book-list" id="bookRows"></div>
  </div>`;
  $("#catalogFilter").value=catUi.status; $("#catalogType").value=catUi.type; $("#catalogSort").value=catUi.sort;
  bindCatalogueEvents();
  let t; $("#catalogSearch").oninput=()=>{clearTimeout(t);t=setTimeout(renderCatalogueRows,isLite()?220:120);};
  $("#catalogSearchClear").onclick=()=>{const s=$("#catalogSearch");s.value="";renderCatalogueRows();s.focus();};
  $("#catalogSort").onchange=renderCatalogueRows;
  renderCatalogueRows();
}

function renderCategories(){ renderTaxonomy(taxonomyConfig("category")); }
/* ---- Shared glass renderer for Classes + Categories (sub-screens of More) ---- */
function taxonomyConfig(kind){
  if(kind==="category")return{p:"category",Cap:"Category",Plural:"Categories",mount:"#categoriesContent",list:categories,editingId:editingCategoryId,ico:"fa-tags",linkKey:"categoryIds",linkedLabel:"Books with categories",nextSort:nextCategorySort(),phId:"e.g. islamic-history",phUr:"مثلاً: اسلامی تاریخ",phEn:"Islamic History"};
  return{p:"class",Cap:"Class",Plural:"Classes",mount:"#classesContent",list:classes,editingId:editingClassId,ico:"fa-layer-group",linkKey:"classIds",linkedLabel:"Books with classes",nextSort:nextClassSort(),phId:"e.g. jamaat-ula",phUr:"مثلاً: جماعت اولی",phEn:"Jamaat Ula"};
}
/* ---- Taxonomy UI state (shared by Categories + Classes) ---- */
const taxUi={category:{open:false,q:"",f:"all"},class:{open:false,q:"",f:"all"}};
function taxSetEditing(P,v){if(P==="category")editingCategoryId=v;else editingClassId=v;}
function taxRender(P){if(P==="category")renderCategories();else renderClasses();}
function openTaxForm(P){taxSetEditing(P,null);taxUi[P].open=true;taxRender(P);}
function closeTaxForm(P){taxSetEditing(P,null);taxUi[P].open=false;taxRender(P);}
function taxSlug(v){return String(v||"").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");}
function syncTaxLock(){document.documentElement.classList.toggle("tx-lock",!!(taxUi.category.open||editingCategoryId||taxUi.class.open||editingClassId));}
function applyTaxFilter(P){
  const root=$(P==="category"?"#categoriesContent":"#classesContent"); if(!root||!root.querySelector(".tx-tools"))return;
  const st=taxUi[P], q=st.q.trim().toLocaleLowerCase(); let shown=0;
  root.querySelectorAll(".tx-row").forEach(r=>{const okQ=!q||(r.dataset.q||"").includes(q);const okF=st.f==="all"||(st.f==="active"?r.dataset.on==="1":r.dataset.on==="0");const ok=okQ&&okF;r.hidden=!ok;if(ok)shown++;});
  const nr=root.querySelector(".tx-noresult"); if(nr)nr.hidden=shown!==0;
  root.querySelectorAll(".tx-chip-f").forEach(c=>{const on=c.dataset.f===st.f;c.classList.toggle("on",on);c.setAttribute("aria-pressed",on?"true":"false");});
}
function renderTaxonomy(k){
  const el=$(k.mount); if(!el)return;
  const P=k.p, st=taxUi[P], total=k.list.length, active=k.list.filter(x=>x.isActive).length, inactive=total-active;
  const editing=k.editingId?k.list.find(x=>x.id===k.editingId):null;
  const open=!!(st.open||editing);
  const tagged=books.filter(b=>b[k.linkKey]?.length).length;
  const pct=total?Math.round(active/total*100):0;
  const lower=k.Plural.toLowerCase();
  const showTools=total>=5;
  if(!showTools){st.q="";st.f="all";}
  const row=c=>{const n=books.filter(b=>b[k.linkKey]?.includes(c.id)).length, nm=c.nameEn||c.id, q=[c.name,c.nameEn,c.id].join(" ").toLocaleLowerCase();
    return `<article class="tx-row ${c.isActive?"":"off"}" data-q="${esc(q)}" data-on="${c.isActive?1:0}"><button class="tx-open" type="button" data-${P}-edit="${esc(c.id)}" aria-label="Edit ${esc(nm)}"><span class="tx-ico">${icon(k.ico)}</span><span class="tx-info"><strong class="tx-ur">${esc(c.name||"—")}</strong><small class="tx-en">${esc(c.nameEn||"—")}</small><span class="tx-meta"><code>${esc(c.id)}</code><span>Sort ${Number(c.sortOrder)||0} · ${n} ${n===1?"book":"books"}</span></span></span></button><div class="tx-side"><button class="tx-switch" type="button" role="switch" aria-checked="${c.isActive?"true":"false"}" data-${P}-toggle="${esc(c.id)}" aria-label="${c.isActive?"Deactivate":"Activate"} ${esc(nm)}"><i></i></button><span class="tx-state">${c.isActive?"Active":"Inactive"}</span></div></article>`;};
  const sheet=open?`<div class="tx-sheet-wrap" id="${P}SheetWrap"><section class="tx-sheet tx-editor" id="${P}Editor" role="dialog" aria-modal="true" aria-labelledby="${P}SheetTitle">
      <div class="tx-grab" aria-hidden="true"></div>
      <header class="tx-sheet-head"><div><h3 id="${P}SheetTitle">${editing?`Edit ${P}`:`New ${P}`}</h3><p>${editing?`ID <code>${esc(editing.id)}</code> can't be changed.`:`Urdu name is what readers see.`}</p></div><button class="tx-x" type="button" id="${P}Close" aria-label="Close">${icon("fa-xmark")}</button></header>
      <div class="tx-sheet-body"><div class="fields">
        <div class="field"><label for="${P}NameUr">Urdu name <em>*</em></label><input id="${P}NameUr" dir="rtl" value="${editing?esc(editing.name||""):""}" placeholder="${k.phUr}" autocomplete="off"></div>
        <div class="field"><label for="${P}NameEn">English / Roman name <em>*</em></label><input id="${P}NameEn" value="${editing?esc(editing.nameEn||""):""}" placeholder="${k.phEn}" autocomplete="off"></div>
        <div class="tx-pair">
          <div class="field"><label for="${P}Id">${k.Cap} ID <em>*</em></label><input id="${P}Id" value="${editing?esc(editing.id):""}" ${editing?"readonly":""} placeholder="${k.phId}" autocomplete="off" autocapitalize="none" spellcheck="false"></div>
          <div class="field"><label for="${P}Sort">Sort</label><input id="${P}Sort" type="number" inputmode="numeric" min="0" step="1" value="${editing?esc(editing.sortOrder??0):esc(k.nextSort)}"></div>
        </div>
        <small class="tx-idhint">${editing?"":"ID is filled from the English name. Lowercase letters, numbers and single hyphens only."}</small>
        <div class="field"><label class="toggle-row" for="${P}Active"><input id="${P}Active" type="checkbox" ${!editing||editing.isActive!==false?"checked":""}><span><strong>Active ${P}</strong><small>Inactive ${lower} can't be newly assigned, but existing book links are kept.</small></span></label></div>
      </div></div>
      <footer class="tx-sheet-foot"><button class="pill-btn primary" type="button" id="save${k.Cap}">${icon("fa-floppy-disk")} ${editing?"Save changes":`Create ${P}`}</button><button class="pill-btn" type="button" id="cancel${k.Cap}">Cancel</button></footer>
    </section></div>`:"";
  el.innerHTML=`<header class="sub-head">
    <button class="sh-back" type="button" data-go="tools" aria-label="Back to More">${icon("fa-arrow-left")}</button>
    <div class="sh-title"><span>More · Taxonomy</span><h1>${k.Plural}</h1></div>
    <button class="pill-btn primary sm sh-new" type="button" id="${P}Reset">${icon("fa-plus")} <span>New</span></button>
  </header>
  <div class="tax-v2">
    <section class="tx-sum" aria-label="${k.Plural} summary">
      <div class="tx-sum-grid">
        <div class="tx-sum-i"><strong>${total}</strong><span>Total</span></div>
        <div class="tx-sum-i ok"><strong>${active}</strong><span>Active</span></div>
        <div class="tx-sum-i off"><strong>${inactive}</strong><span>Inactive</span></div>
        <div class="tx-sum-i" title="${k.linkedLabel}" aria-label="${k.linkedLabel}"><strong>${tagged}</strong><span>Tagged</span></div>
      </div>
      ${total?`<div class="tx-bar" role="img" aria-label="${pct}% active"><b style="width:${pct}%"></b></div>`:""}
    </section>
    ${showTools?`<div class="tx-tools"><label class="tx-search">${icon("fa-magnifying-glass")}<input id="${P}Search" type="search" placeholder="Search ${lower}…" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search" aria-label="Search ${lower}"><button class="tx-clear" type="button" id="${P}SearchClear" aria-label="Clear search" ${st.q?"":"hidden"}>${icon("fa-xmark")}</button></label>
      <div class="tx-chips" role="group" aria-label="Filter ${lower}"><button class="tx-chip-f on" type="button" data-f="all" aria-pressed="true">All <b>${total}</b></button><button class="tx-chip-f" type="button" data-f="active" aria-pressed="false">Active <b>${active}</b></button><button class="tx-chip-f" type="button" data-f="inactive" aria-pressed="false">Inactive <b>${inactive}</b></button></div></div>`:""}
    ${total?`<p class="tx-hint">Tap a row to edit. Use the switch to activate or deactivate.</p><div class="tx-list">${k.list.map(row).join("")}</div><div class="tx-noresult" hidden>${icon("fa-magnifying-glass")}<strong>No matching ${lower}</strong><span>Try a different search or filter.</span></div>`:`<div class="tx-empty"><div class="tx-empty-ico">${icon(k.ico)}</div><strong>No ${lower} yet</strong><span>Create the first ${P} to start organising books.</span><button class="pill-btn primary" type="button" id="${P}EmptyNew">${icon("fa-plus")} Create ${P}</button></div>`}
    ${sheet}
  </div>`;
  const save=P==="category"?saveCategory:saveClass, toggle=P==="category"?toggleCategory:toggleClass;
  $("#"+P+"Reset").onclick=()=>openTaxForm(P);
  const em=$("#"+P+"EmptyNew"); if(em)em.onclick=()=>openTaxForm(P);
  el.querySelectorAll(`[data-${P}-edit]`).forEach(b=>b.onclick=()=>{taxSetEditing(P,b.getAttribute(`data-${P}-edit`));st.open=true;taxRender(P);});
  el.querySelectorAll(`[data-${P}-toggle]`).forEach(b=>b.onclick=()=>toggle(b.getAttribute(`data-${P}-toggle`)));
  const s=$("#"+P+"Search"), clr=$("#"+P+"SearchClear");
  if(s){s.oninput=()=>{st.q=s.value;if(clr)clr.hidden=!s.value;applyTaxFilter(P);};}
  if(clr)clr.onclick=()=>{s.value="";st.q="";clr.hidden=true;applyTaxFilter(P);s.focus();};
  el.querySelectorAll(".tx-chip-f").forEach(c=>c.onclick=()=>{st.f=c.dataset.f;applyTaxFilter(P);});
  applyTaxFilter(P);
  if(open){
    const close=()=>closeTaxForm(P), ed=$("#"+P+"Editor");
    $("#"+P+"Close").onclick=close; $("#cancel"+k.Cap).onclick=close; $("#save"+k.Cap).onclick=save;
    $("#"+P+"SheetWrap").onclick=e=>{if(e.target.id===P+"SheetWrap")close();};
    ed.addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.tagName==="INPUT"&&e.target.type!=="checkbox"){e.preventDefault();save();}});
    if(!editing){
      const idEl=$("#"+P+"Id"), enEl=$("#"+P+"NameEn"); let touched=false;
      idEl.addEventListener("input",()=>{touched=true;});
      enEl.addEventListener("input",()=>{if(!touched)idEl.value=taxSlug(enEl.value);});
      try{$("#"+P+"NameUr").focus({preventScroll:true});}catch{}
    }
  }
  syncTaxLock();
}
if(!window.__txEsc){window.__txEsc=true;document.addEventListener("keydown",e=>{if(e.key!=="Escape")return;if(document.getElementById("bkMenuWrap")){closeBookMenu();return;}if(taxUi.category.open||editingCategoryId)closeTaxForm("category");else if(taxUi.class.open||editingClassId)closeTaxForm("class");});}
function nextCategorySort(){return categories.length?Math.max(...categories.map(c=>Number(c.sortOrder)||0))+1:0;}
function resetCategoryForm(){editingCategoryId=null;renderCategories();}
function categoryFormValue(){return{id:String($("#categoryId")?.value||"").trim(),nameUr:String($("#categoryNameUr")?.value||"").trim(),nameEn:String($("#categoryNameEn")?.value||"").trim(),sortOrder:Math.max(0,Number($("#categorySort")?.value||0)),isActive:!!$("#categoryActive")?.checked};}
function validateCategory(c){const e=[];if(!c.id)e.push("Category ID is required.");else if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(c.id))e.push("Category ID must use lowercase letters, numbers and single hyphens only.");if(!c.nameUr)e.push("Urdu name is required.");if(!c.nameEn)e.push("English / Roman name is required.");if(!Number.isInteger(c.sortOrder)||c.sortOrder<0)e.push("Sort order must be a non-negative whole number.");const dupId=categories.find(x=>x.id===c.id&&x.id!==editingCategoryId);if(dupId)e.push("This category ID already exists.");const norm=x=>String(x||"").trim().toLocaleLowerCase();const dupName=categories.find(x=>x.id!==editingCategoryId&&(norm(x.nameEn)===norm(c.nameEn)||norm(x.name)===norm(c.nameUr)));if(dupName)e.push("A category with the same name already exists.");return e;}
async function saveCategory(){const c=categoryFormValue(),errors=validateCategory(c);if(errors.length){showCategoryValidation(errors);notify("Please fix the category fields first.","error");return;}const btn=$("#saveCategory");btn.disabled=true;try{const row={id:c.id,name_ur:c.nameUr,name_en:c.nameEn,sort_order:c.sortOrder,is_active:c.isActive};const r=editingCategoryId?await supabase.from("categories").update(row).eq("id",editingCategoryId):await supabase.from("categories").insert(row);if(r.error)throw r.error;notify(`${editingCategoryId?"Category updated":"Category created"}: ${esc(c.nameEn)}`,"success");editingCategoryId=null;taxUi.category.open=false;await loadData({silent:true});setView("categories");}catch(err){notify(`Category save failed: ${esc(err?.message||"Database error")}`,"error");}finally{btn.disabled=false;}}
function showCategoryValidation(items){const ed=$("#categoryEditor");if(!ed)return;let box=$("#categoryValidation");if(!box){box=document.createElement("div");box.id="categoryValidation";box.className="validation";(ed.querySelector(".tx-sheet-body")||ed).appendChild(box);}box.innerHTML=`<strong>Fix these issues</strong><ul>${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`;box.scrollIntoView({block:"nearest",behavior:"smooth"});}
async function toggleCategory(id){const c=categories.find(x=>x.id===id);if(!c)return;const action=c.isActive?"deactivate":"activate";if(c.isActive&&books.some(b=>b.categoryIds?.includes(id))){if(!await confirmDialog({title:`Deactivate ${c.nameEn}?`,message:"Existing book links will remain, but new books will no longer be able to select this category.",confirmText:"Deactivate",cancelText:"Keep active",iconName:"fa-toggle-off",tone:"danger"}))return;}if(!c.isActive){if(!await confirmDialog({title:`Activate ${c.nameEn}?`,message:"It will become available in the book form.",confirmText:"Activate",cancelText:"Cancel",iconName:"fa-toggle-on"}))return;}try{const r=await supabase.from("categories").update({is_active:!c.isActive}).eq("id",id);if(r.error)throw r.error;notify(`Category ${action}d.` ,"success");await loadData({silent:true});setView("categories");}catch(err){notify(`Could not ${action} category: ${esc(err?.message||"Database error")}`,"error");}}
function bindCategoryEvents(){$("#categoryReset").onclick=()=>resetCategoryForm();$("#cancelCategory").onclick=()=>resetCategoryForm();$("#saveCategory").onclick=saveCategory;document.querySelectorAll("[data-category-edit]").forEach(b=>b.onclick=()=>{editingCategoryId=b.dataset.categoryEdit;renderCategories();document.querySelector("#categoryEditor")?.scrollIntoView({behavior:isLite()?"auto":"smooth",block:"start"});});document.querySelectorAll("[data-category-toggle]").forEach(b=>b.onclick=()=>toggleCategory(b.dataset.categoryToggle));}
function renderClasses(){ renderTaxonomy(taxonomyConfig("class")); }
function resetClassForm(){editingClassId=null;renderClasses();}
function nextClassSort(){return classes.reduce((m,c)=>Math.max(m,Number(c.sortOrder)||0),-1)+1;}
function classFormValue(){return{id:String($("#classId")?.value||"").trim(),nameUr:String($("#classNameUr")?.value||"").trim(),nameEn:String($("#classNameEn")?.value||"").trim(),sortOrder:Math.max(0,Number($("#classSort")?.value||0)),isActive:!!$("#classActive")?.checked};}
function validateClass(c){const e=[];if(!c.id)e.push("Class ID is required.");else if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(c.id))e.push("Class ID must use lowercase letters, numbers and single hyphens only.");if(!c.nameUr)e.push("Urdu name is required.");if(!c.nameEn)e.push("English / Roman name is required.");if(!Number.isInteger(c.sortOrder)||c.sortOrder<0)e.push("Sort order must be a non-negative whole number.");const dupId=classes.find(x=>x.id===c.id&&x.id!==editingClassId);if(dupId)e.push("This class ID already exists.");const norm=x=>String(x||"").trim().toLocaleLowerCase();const dupName=classes.find(x=>x.id!==editingClassId&&(norm(x.nameEn)===norm(c.nameEn)||norm(x.name)===norm(c.nameUr)));if(dupName)e.push("A class with the same name already exists.");return e;}
async function saveClass(){const c=classFormValue(),errors=validateClass(c);if(errors.length){showClassValidation(errors);notify("Please fix the class fields first.","error");return;}const btn=$("#saveClass");btn.disabled=true;try{const row={id:c.id,name_ur:c.nameUr,name_en:c.nameEn,sort_order:c.sortOrder,is_active:c.isActive};const r=editingClassId?await supabase.from("classes").update(row).eq("id",editingClassId):await supabase.from("classes").insert(row);if(r.error)throw r.error;notify(`${editingClassId?"Class updated":"Class created"}: ${esc(c.nameEn)}`,"success");editingClassId=null;taxUi.class.open=false;await loadData({silent:true});setView("classes");}catch(err){notify(`Class save failed: ${esc(err?.message||"Database error")}`,"error");}finally{btn.disabled=false;}}
function showClassValidation(items){const ed=$("#classEditor");if(!ed)return;let box=$("#classValidation");if(!box){box=document.createElement("div");box.id="classValidation";box.className="validation";(ed.querySelector(".tx-sheet-body")||ed).appendChild(box);}box.innerHTML=`<strong>Fix these issues</strong><ul>${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`;box.scrollIntoView({block:"nearest",behavior:"smooth"});}
async function toggleClass(id){const c=classes.find(x=>x.id===id);if(!c)return;const action=c.isActive?"deactivate":"activate";const linked=books.filter(b=>b.classIds?.includes(id)).length;if(c.isActive&&linked){if(!await confirmDialog({title:`Deactivate ${c.nameEn}?`,message:`${linked} existing book link${linked===1?"":"s"} will remain, but new books will no longer be able to select this class.`,confirmText:"Deactivate",cancelText:"Keep active",iconName:"fa-toggle-off",tone:"danger"}))return;}if(!c.isActive){if(!await confirmDialog({title:`Activate ${c.nameEn}?`,message:"It will become available in the book form.",confirmText:"Activate",cancelText:"Cancel",iconName:"fa-toggle-on"}))return;}try{const r=await supabase.from("classes").update({is_active:!c.isActive}).eq("id",id);if(r.error)throw r.error;notify(`Class ${action}d.` ,"success");await loadData({silent:true});setView("classes");}catch(err){notify(`Could not ${action} class: ${esc(err?.message||"Database error")}`,"error");}}
function bindClassEvents(){$("#classReset").onclick=()=>resetClassForm();$("#cancelClass").onclick=()=>resetClassForm();$("#saveClass").onclick=saveClass;document.querySelectorAll("[data-class-edit]").forEach(b=>b.onclick=()=>{editingClassId=b.dataset.classEdit;renderClasses();document.querySelector("#classEditor")?.scrollIntoView({behavior:isLite()?"auto":"smooth",block:"start"});});document.querySelectorAll("[data-class-toggle]").forEach(b=>b.onclick=()=>toggleClass(b.dataset.classToggle));}

function perfNoteHtml(){
  const mode=getPerfMode();
  if(mode==="full")return `${icon("fa-gem")}<span><b>Full</b> — glass blur, soft shadows and smooth animations. Can feel slow on low-end phones.</span>`;
  if(mode==="lite")return `${icon("fa-bolt")}<span><b>Lite</b> — blur, animations and heavy shadows are off, and long lists load lazily. Best for low-end phones.</span>`;
  const d=detectDevice(),eff=resolvePerf("auto");
  return `${icon("fa-wand-magic-sparkles")}<span><b>Auto</b> is using <b>${eff==="lite"?"Lite":"Full"}</b> on this device${d.lite?` (${esc(d.reason)})`:` — it looks capable`}.</span>`;
}
function bindPerfEvents(){
  document.querySelectorAll("[data-perf-set]").forEach(b=>b.onclick=()=>{
    const mode=b.dataset.perfSet; setPerfMode(mode);
    document.querySelectorAll("[data-perf-set]").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    const note=$("#perfNote"); if(note)note.innerHTML=perfNoteHtml();
    notify(`Performance mode: ${mode==="auto"?"Auto":mode==="full"?"Full":"Lite"}`,"success");
  });
}
function renderTools(){
  const activeClasses=classes.filter(x=>x.isActive).length, activeCats=categories.filter(x=>x.isActive).length;
  const perfMode=getPerfMode();
  const perfOpts=[["auto","fa-wand-magic-sparkles","Auto","Recommended"],["full","fa-gem","Full","Best looks"],["lite","fa-bolt","Lite","Fastest"]];
  const org=(go,ic,title,sub)=>`<button class="quick-action" data-go="${go}" type="button"><span class="qa-ico">${icon(ic)}</span><span class="qa-text"><strong>${title}</strong><small>${sub}</small></span>${icon("fa-chevron-right")}</button>`;
  const tool=(tone,ic,title,desc,btn,extra="")=>`<section class="tg-card ${tone}"><span class="tg-ico">${icon(ic)}</span><div class="tg-text"><h3>${title}</h3><p>${desc}</p></div>${btn}${extra}</section>`;
  const rule=(ic,text)=>`<li><span class="rl-ico">${icon(ic)}</span><span>${text}</span></li>`;
  $("#toolsContent").innerHTML=`<div class="tools-v2">
  <section class="tools-hero">
    <div class="th-copy"><span class="th-kicker">Settings &amp; tools</span><h2>More</h2><p>Performance, library organisation, backup and restore.</p></div>
    <div class="th-badge" aria-label="${books.length} books in catalogue"><strong>${books.length}</strong><span>${books.length===1?"book":"books"}</span></div>
  </section>
  <section class="glass-card perf-card">
    <header class="glass-head"><div><h3>Performance</h3><p>Choose how the app looks and runs on this device</p></div><span class="rl-head-ico">${icon("fa-gauge-high")}</span></header>
    <div class="perf-seg" role="group" aria-label="Performance mode">${perfOpts.map(([v,ic,l,sub])=>`<button type="button" data-perf-set="${v}" aria-pressed="${perfMode===v}">${icon(ic)}<b>${l}</b><small>${sub}</small></button>`).join("")}</div>
    <p class="perf-note" id="perfNote" aria-live="polite">${perfNoteHtml()}</p>
  </section>
  <section class="glass-card">
    <header class="glass-head"><div><h3>App lock</h3><p>Optional 6-digit PIN, stored only on this device</p></div><span class="rl-head-ico">${icon("fa-lock")}</span></header>
    <div id="lockBody"></div>
  </section>
  <section class="glass-card">
    <header class="glass-head"><div><h3>Organise library</h3><p>Manage the categories and classes used by books</p></div></header>
    <div class="qa-list org-list">
      ${org("classes","fa-layer-group","Classes",`${activeClasses} active · ${classes.length} total`)}
      ${org("categories","fa-tags","Categories",`${activeCats} active · ${categories.length} total`)}
    </div>
  </section>
  <div class="tg-grid">
    ${tool("tone-a","fa-shield-halved","Backup","Export the current Supabase catalogue as JSON.",`<button class="pill-btn" id="export" type="button">${icon("fa-file-export")} Export JSON</button>`)}
    ${tool("tone-b","fa-file-import","Import","Validate and upsert a JSON catalogue into Supabase.",`<button class="pill-btn" id="import" type="button">${icon("fa-file-import")} Import JSON</button>`,`<input id="importFile" type="file" accept="application/json,.json" hidden>`)}
    ${tool("tone-d","fa-eye","Record preview","Preview the current form before saving.",`<button class="pill-btn" id="preview" type="button">${icon("fa-eye")} Preview</button>`)}
    ${tool("tone-c tg-warn","fa-database","Local safety cache","Used only to preserve work if Supabase temporarily fails.",`<button class="pill-btn warn" id="clearLocal" type="button">${icon("fa-trash-can")} Clear local cache</button>`)}
  </div>
  <section class="glass-card">
    <header class="glass-head"><div><h3>Manager rules</h3><p>Keep these in mind while editing</p></div><span class="rl-head-ico">${icon("fa-circle-info")}</span></header>
    <ul class="rules-list">
      ${rule("fa-cloud","Supabase is the live source of truth.")}
      ${rule("fa-triangle-exclamation","Deleting a book is permanent for the catalogue record.")}
      ${rule("fa-image","Generated covers upload automatically to the Supabase <code>covers</code> Storage bucket — no manual copy step needed.")}
      ${rule("fa-key","Never put a Supabase service-role key in this client.")}
    </ul>
  </section>
  </div>`;
  bindToolsEvents(); bindPerfEvents(); bindLockEvents();
}

function bindLockEvents(){
  const L=window.MKLock; const body=$("#lockBody"); if(!L||!body)return;
  const btn=(id,ic,txt,cls="")=>`<button class="pill-btn ${cls}" id="${id}" type="button">${icon(ic)} ${txt}</button>`;
  const paint=async()=>{
    const host=$("#lockBody"); if(!host)return;
    if(!L.isEnabled()){
      host.innerHTML=`<p class="perf-note">App Lock is off. Turn it on to ask for a PIN every time the app opens.</p><div class="lock-actions">${btn("lockOn","fa-lock","Turn on App Lock","primary")}</div>`;
    }else{
      const bioOk=await L.bioAvailable();
      const why=bioOk?"":await L.bioStatus();
      const hints={"noHardware":"This device has no fingerprint or face sensor.","biometryUnavailable":"The biometric sensor is not available right now.","not-enrolled":"Biometric unlock needs a fingerprint or face saved in your phone settings.","no-plugin":"Biometric support is not part of this build.","unavailable":"Biometrics are not available on this device."};
      const hint=bioOk?"":`<p class="perf-note">${icon("fa-fingerprint")} ${hints[why]||"Biometric check did not find support in this app."} <small>(status: ${esc(why)})</small></p>`;
      host.innerHTML=`<p class="perf-note"><strong>App Lock is on.</strong> The app locks when you return after a short break.</p><div class="lock-actions">${btn("lockChange","fa-key","Change PIN")}${btn("lockNow","fa-lock","Lock now")}${bioOk?btn("lockBio","fa-fingerprint",L.bioEnabled()?"Biometric: On":"Biometric: Off"):""}${btn("lockOff","fa-lock-open","Turn off","warn")}</div>${hint}`;
    }
    $("#lockOn")?.addEventListener("click",()=>L.enable());
    $("#lockChange")?.addEventListener("click",()=>L.changePin());
    $("#lockNow")?.addEventListener("click",()=>L.lockNow());
    $("#lockOff")?.addEventListener("click",()=>L.disable());
    $("#lockBio")?.addEventListener("click",async()=>{const ok=await L.setBio(!L.bioEnabled()); if(!ok)notify("Biometric setting was not changed.","error"); else notify(L.bioEnabled()?"Biometric unlock is on.":"Biometric unlock is off.","success"); paint();});
  };
  paint();
  if(!bindLockEvents.bound){bindLockEvents.bound=true; window.addEventListener("mklockchange",()=>{ if($("#lockBody"))bindLockEvents(); });}
}

async function loadData({silent=false}={}){
  if(loading)return; loading=true; setSyncState("busy","Loading catalogue…");
  try{
    const [cr,catr,br,mr,bcr]=await Promise.all([supabase.from("classes").select("*").order("sort_order").order("id"),supabase.from("categories").select("*").order("sort_order").order("id"),supabase.from("books").select("*").order("added_at",{ascending:false}).order("created_at",{ascending:false}),supabase.from("book_categories").select("book_id,category_id"),supabase.from("book_classes").select("book_id,class_id")]);
    for(const r of [cr,catr,br,mr,bcr])if(r.error)throw r.error;
    classes=(cr.data||[]).map(c=>({id:c.id,name:c.name_ur,nameEn:c.name_en,sortOrder:c.sort_order,isActive:c.is_active!==false})); categories=(catr.data||[]).map(c=>({id:c.id,name:c.name_ur,nameEn:c.name_en,sortOrder:c.sort_order,isActive:c.is_active!==false}));
    const categoryMap=new Map(); (mr.data||[]).forEach(x=>{if(!categoryMap.has(x.book_id))categoryMap.set(x.book_id,[]);categoryMap.get(x.book_id).push(x.category_id);});
    const classMap=new Map(); (bcr.data||[]).forEach(x=>{if(!classMap.has(x.book_id))classMap.set(x.book_id,[]);classMap.get(x.book_id).push(x.class_id);});
    books=(br.data||[]).map(mapDbBook); books.forEach(b=>{b.classIds=classMap.get(b.id)|| (b.classId?[b.classId]:[]); b.categoryIds=categoryMap.get(b.id)||[];}); persist(); dataLoaded=true; setSyncState("ok",`${books.length} books synced`); renderAllViews();
    const savedView=location.hash.slice(1)||localStorage.getItem(VIEW_KEY)||"dashboard"; setView(savedView,{push:false}); if(!silent)notify(`Catalogue refreshed — ${books.length} book${books.length===1?"":"s"}.`,"success");
  }catch(err){
    dataLoaded=true; setSyncState("error","Offline / error"); try{const local=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");books=Array.isArray(local)?local:[];}catch{books=[];} renderAllViews(); setView(location.hash.slice(1)||"dashboard",{push:false}); if(!silent)notify(`Supabase unavailable. Local safety cache shown: ${esc(err?.message||"Unknown error")}`,"error");
  }finally{loading=false;}
}
function sourceTypeFromUrls(pdfUrl="",pageUrl="",name=""){const text=`${pdfUrl} ${pageUrl} ${name}`.toLowerCase();if(text.includes("archive.org"))return "archive";if(text.includes("drive.google.com")||text.includes("googleusercontent.com"))return "drive";return "direct";}
function mapDbBook(r){const classId=r.class_id||"";const pdfUrl=r.pdf_url||"";const pageUrl=r.source_page_url||"";return{id:r.id,title:r.title||"",titleEn:r.title_en||"",author:r.author||"",description:r.description||"",classId,classIds:classId?[classId]:[],bookType:r.book_type||"matn",categoryIds:[],keywords:Array.isArray(r.keywords)?r.keywords:[],cover:r.cover_path||"",pdfUrl,source:{type:sourceTypeFromUrls(pdfUrl,pageUrl,r.source_name||""),name:r.source_name||"",pageUrl},pages:r.pages == null ? null : r.pages,status:r.status||"review",addedAt:r.added_at||r.created_at||today()};}
function normalizeLocalBook(b){const classId=String(b?.classId||"").trim();return {...b,classId,classIds:Array.isArray(b?.classIds)?b.classIds.map(String):classId?[classId]:[],categoryIds:Array.isArray(b?.categoryIds)?b.categoryIds.map(String):[]};}
function persist(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(books));}catch{}}

function initNavigation(){ document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>{if(b.dataset.go)setView(b.dataset.go);else setView(b.dataset.view);})); const h=()=>setView(location.hash.slice(1)||"dashboard",{push:false}); window.addEventListener("popstate",h); window.addEventListener("hashchange",h); setView(location.hash.slice(1)||localStorage.getItem(VIEW_KEY)||"dashboard",{push:false}); }
function setView(view,{push=true}={}){const allowed=new Set(["dashboard","add","catalogue","categories","classes","tools"]);if(!allowed.has(view))view="dashboard"; if(view!=="add"&&isDirty()){if(!confirm("You have unsaved changes. Leave this form?")){return;}} closeBookMenu(); if(taxUi.category.open||editingCategoryId||taxUi.class.open||editingClassId){taxUi.category.open=taxUi.class.open=false;editingCategoryId=editingClassId=null;renderCategories();renderClasses();} document.querySelectorAll("[data-view-section]").forEach(x=>x.hidden=x.dataset.viewSection!==view); document.querySelectorAll(".nav-item[data-view]").forEach(x=>{const active=x.dataset.view===view||(x.dataset.view==="tools"&&(view==="categories"||view==="classes"));x.classList.toggle("active",active);if(active)x.setAttribute("aria-current","page");else x.removeAttribute("aria-current");}); const names={dashboard:["Workspace","Dashboard"],add:[editingId?"Record":"New record",editingId?"Edit Book":"Add Book"],catalogue:["Library records","Catalogue"],categories:["Taxonomy","Categories"],classes:["Taxonomy","Classes"],tools:["Settings & tools","More"]}; $("#pageKicker").textContent=names[view][0]; $("#pageTitle").textContent=names[view][1]; document.body.classList.toggle("focus-mode",view==="categories"||view==="classes"); localStorage.setItem(VIEW_KEY,view); if(push&&location.hash!==`#${view}`)history.pushState({view},"",`#${view}`); $("#sidebar")?.classList.remove("open"); window.scrollTo({top:0,behavior:isLite()?"auto":"smooth"}); }
function isDirty(){if(!$("#title"))return false;const now=JSON.stringify(collectForm());return formSnapshot && now!==formSnapshot;}
function snapshotForm(){try{formSnapshot=JSON.stringify(collectForm());}catch{formSnapshot="";}}

function bindGlobalEvents(){ $("#signOut").onclick=async()=>{const dirty=isDirty();const ok=await confirmDialog({title:"Sign out?",message:dirty?"You have unsaved changes on the Add screen. They will be lost if you sign out.":"You will need to sign in again to manage the library.",confirmText:"Sign out",cancelText:"Stay",iconName:"fa-power-off",tone:"danger"});if(ok)signOutManager();}; $("#refresh").onclick=async()=>{if(isDirty()&&!confirm("You have unsaved changes. Refreshing will discard them. Continue?"))return;const b=$("#refresh");b.disabled=true;try{await loadData();}finally{b.disabled=false;}}; $("#theme").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("krul_manager_theme",document.body.classList.contains("dark")?"dark":"light");}; if(localStorage.getItem("krul_manager_theme")==="dark")document.body.classList.add("dark"); manager.addEventListener("click",e=>{const go=e.target.closest("[data-go]");if(go)setView(go.dataset.go);const edit=e.target.closest("[data-edit]");if(edit){const b=books.find(x=>x.id===edit.dataset.edit);if(b)fillForm(b);setView("add");}}); window.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();setView("catalogue");setTimeout(()=>$("#catalogSearch")?.focus(),80);}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="n"){e.preventDefault();if(!isDirty()||confirm("Start a new book and discard unsaved changes?")){resetForm();renderAdd();setView("add");}}}); }

function bindFormEvents(){ $("#formNew").onclick=()=>{if(!isDirty()||confirm("Start a new book and discard unsaved changes?")){resetForm();renderAdd();setView("add");}}; $("#saveBook").onclick=()=>saveBook(false); $("#saveNew").onclick=()=>saveBook(true); $("#resolveSource").onclick=resolvePdfFromSource; $("#testSource").onclick=testSource; ["#sourceType","#sourcePage","#pdf"].forEach(sel=>$(sel)?.addEventListener("input",updateSourceStatus)); $("#validate").onclick=()=>{const r=validateRecord(collectForm(),true);if(r.errors.length){showValidation(r.errors,"Fix these issues");notify(`${r.errors.length} issue(s) found.` ,"error");}else notify(r.warnings.length?`Valid, with ${r.warnings.length} warning(s).`:"Record is valid and ready to save.",r.warnings.length?"warning":"success");}; $("#generateCover").onclick=generateCover; $("#downloadCover").onclick=downloadCover; $("#coverFile").onchange=()=>{const f=$("#coverFile").files[0];if(f){$("#coverStatus").className="status ready";$("#coverStatus").textContent=f.type.startsWith("image/")?"Local image selected":"Local PDF selected";}}; document.querySelectorAll("[data-scroll-to]").forEach(el=>el.onclick=()=>{document.getElementById(el.dataset.scrollTo)?.scrollIntoView({behavior:isLite()?"auto":"smooth",block:"start"});document.querySelectorAll("[data-scroll-to]").forEach(s=>s.classList.toggle("active",s===el));}); if(!window.__krStepSpy){window.__krStepSpy=true;window.addEventListener("scroll",()=>{const steps=document.querySelectorAll(".stepper [data-scroll-to]");if(!steps.length||!steps[0].offsetParent)return;let cur=steps[0].dataset.scrollTo;steps.forEach(x=>{const t=document.getElementById(x.dataset.scrollTo);if(t&&t.getBoundingClientRect().top<190)cur=x.dataset.scrollTo;});steps.forEach(x=>x.classList.toggle("active",x.dataset.scrollTo===cur));},{passive:true});} snapshotForm(); }
function bindCatalogueEvents(){
  const root=document.querySelector(".cat-v2"); if(!root)return;
  const sync=()=>root.querySelectorAll("[data-seg-for]").forEach(g=>{const sel=document.getElementById(g.dataset.segFor);if(!sel)return;g.querySelectorAll("button").forEach(b=>{const on=b.dataset.val===sel.value;b.classList.toggle("on",on);b.setAttribute("aria-pressed",on?"true":"false");});});
  const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,"value");
  root.querySelectorAll(".seg-native").forEach(sel=>Object.defineProperty(sel,"value",{configurable:true,get(){return d.get.call(this);},set(v){d.set.call(this,v);sync();}}));
  root.querySelectorAll("[data-seg-for] button").forEach(b=>b.addEventListener("click",()=>{const sel=document.getElementById(b.parentElement.dataset.segFor);if(!sel)return;sel.value=b.dataset.val;renderCatalogueRows();}));
  $("#catalogSearch").oninput=renderCatalogueRows;
  $("#clearFilters").onclick=()=>{$("#catalogSearch").value="";$("#catalogFilter").value="all";$("#catalogType").value="all";renderCatalogueRows();};
  sync();
}
function confirmDialog({title="Are you sure?",message="",confirmText="Confirm",cancelText="Cancel",iconName="fa-circle-question",tone="primary"}={}){
  return new Promise(resolve=>{
    const host=$("#modal"); if(!host){resolve(window.confirm(`${title}\n${message}`));return;}
    const prev=document.activeElement;
    host.className="modal-backdrop glass-modal";
    host.innerHTML=`<div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="dlgTitle" aria-describedby="dlgMsg"><span class="dlg-ico ${esc(tone)}">${icon(iconName)}</span><h3 id="dlgTitle">${esc(title)}</h3><p id="dlgMsg">${esc(message)}</p><div class="dlg-actions"><button type="button" class="pill-btn" id="dlgCancel">${esc(cancelText)}</button><button type="button" class="pill-btn ${tone==="danger"?"danger":"primary"}" id="dlgOk">${esc(confirmText)}</button></div></div>`;
    host.hidden=false; document.body.classList.add("modal-open");
    const finish=v=>{host.hidden=true;host.innerHTML="";document.body.classList.remove("modal-open");document.removeEventListener("keydown",onKey,true);try{prev?.focus?.();}catch{}resolve(v);};
    const onKey=e=>{if(e.key==="Escape"){e.preventDefault();finish(false);}if(e.key==="Tab"){const f=[$("#dlgCancel"),$("#dlgOk")];const i=f.indexOf(document.activeElement);e.preventDefault();f[(i+(e.shiftKey?-1:1)+f.length)%f.length].focus();}};
    document.addEventListener("keydown",onKey,true);
    host.onclick=e=>{if(e.target===host)finish(false);};
    $("#dlgCancel").onclick=()=>finish(false); $("#dlgOk").onclick=()=>finish(true);
    $("#dlgCancel").focus();
  });
}
function bindToolsEvents(){ $("#export").onclick=exportJSON; $("#preview").onclick=()=>{setView("add");previewRecord();}; $("#import").onclick=()=>$("#importFile").click(); $("#importFile").onchange=importJSON; $("#clearLocal").onclick=clearLocalDraft; }

function renderClassPicker(selected=[]){const el=$("#classPicker");if(!el)return;const chosen=new Set(Array.isArray(selected)?selected:(selected?[selected]:[]));const active=classes.filter(c=>c.isActive);const selectedInactive=classes.filter(c=>!c.isActive&&chosen.has(c.id));const options=[...active,...selectedInactive];el.innerHTML=options.length?options.map(c=>`<label class="category-chip"><input type="checkbox" value="${esc(c.id)}" ${chosen.has(c.id)?"checked":""}><span>${esc(c.nameEn||c.id)}${c.name?`<small>${esc(c.name)}</small>`:""}${!c.isActive?`<small class="inactive-option">Inactive — remove if no longer needed</small>`:""}</span></label>`).join(""):`<span class="muted">No active classes.</span>`;$("#classHint").textContent=active.length?`${active.length} active · optional. Existing inactive selections are shown so they can be removed.`:"No active classes available.";}
function renderCategoryPicker(selected=[]){const el=$("#categoryPicker");if(!el)return;const chosen=new Set(selected);const active=categories.filter(c=>c.isActive);el.innerHTML=active.length?active.map(c=>`<label class="category-chip"><input type="checkbox" value="${esc(c.id)}" ${chosen.has(c.id)?"checked":""}><span>${esc(c.nameEn||c.id)}${c.name?`<small>${esc(c.name)}</small>`:""}</span></label>`).join(""):`<span class="muted">No active categories.</span>`;$("#categoryHint").textContent=active.length?`${active.length} active · optional. Select one or more if needed.`:"No active categories available.";}
function getSelectedClassesSafe(){return [...document.querySelectorAll("#classPicker input:checked")].map(x=>x.value);}
function getSelectedCategoriesSafe(){return [...document.querySelectorAll("#categoryPicker input:checked")].map(x=>x.value);}
function collectForm(){const existing=editingId?books.find(x=>x.id===editingId):null;const classIds=getSelectedClassesSafe();const pdfUrl=normalizeUrl($("#pdf")?.value);const pageUrl=normalizeUrl($("#sourcePage")?.value);const type=$("#sourceType")?.value||sourceTypeFromUrls(pdfUrl,pageUrl,$("#sourceName")?.value);return{id:existing?.id||nextId(),title:$("#title")?.value.trim()||"",titleEn:$("#titleEn")?.value.trim()||"",author:$("#author")?.value.trim()||"",description:$("#description")?.value.trim()||"",classIds,classId:classIds[0]||"",bookType:$("#type")?.value||"matn",categoryIds:getSelectedCategoriesSafe(),keywords:csv($("#keywords")?.value),cover:selectedCover.path||existing?.cover||"",pdfUrl,source:{type:type==="auto"?sourceTypeFromUrls(pdfUrl,pageUrl,$("#sourceName")?.value):type,name:$("#sourceName")?.value.trim()||"",pageUrl},pages:Number.isInteger(Number($("#pages")?.value))&&Number($("#pages")?.value)>0?Number($("#pages")?.value):null,status:$("#status")?.value||"available",addedAt:existing?.addedAt||today()};}
function validateRecord(b){const errors=[],warnings=[];if(!b.title)errors.push("Title is required.");if((!Array.isArray(b.classIds)||!b.classIds.length)&&(!Array.isArray(b.categoryIds)||!b.categoryIds.length))errors.push("Select at least one class or at least one category. A book cannot be saved with both left empty.");if((b.classIds||[]).some(id=>!classes.some(c=>c.id===id)))errors.push("One or more selected classes no longer exist.");if(!["matn","sharah"].includes(b.bookType))errors.push("Book type is invalid.");if(!isHttpUrl(b.pdfUrl))errors.push("PDF URL must be a valid HTTP(S) URL.");if(b.source.pageUrl&&!isHttpUrl(b.source.pageUrl))errors.push("Source Page URL must be HTTP(S).");if(!["archive","drive","direct"].includes(b.source.type))errors.push("Source type is invalid.");let pdfHost="",pageHost="";try{pdfHost=new URL(b.pdfUrl).hostname.toLowerCase();}catch{}try{pageHost=new URL(b.source.pageUrl||b.pdfUrl).hostname.toLowerCase();}catch{}if(b.source.type==="archive"&&pdfHost&&!/(^|\.)archive\.org$/i.test(pdfHost))errors.push("Internet Archive source must resolve to an archive.org PDF URL.");if(b.source.type==="archive"&&!pdfHost)errors.push("Internet Archive source URL could not be parsed.");if(b.source.type==="drive"&&pageHost&&!/(^|\.)drive\.google\.com$/i.test(pageHost))errors.push("Google Drive source must use a drive.google.com URL.");if(b.pages!==null&&(!Number.isInteger(b.pages)||b.pages<1))errors.push("Pages must be a positive whole number.");if(b.categoryIds.some(id=>!categories.some(c=>c.id===id&&c.isActive)))errors.push("One or more selected categories are no longer active.");const dup=books.find(x=>x.id!==b.id&&b.pdfUrl&&normalizeUrl(x.pdfUrl)===b.pdfUrl);if(dup)warnings.push(`The same PDF URL is already used by ${dup.id}.`);if(b.source.type==="drive")warnings.push("Google Drive links must be publicly accessible for the Library reader/download flow.");return{errors,warnings};}
function showValidation(items,title="Validation"){$("#result").innerHTML=`<div class="validation"><strong>${esc(title)}</strong><ul>${items.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`;}
function statusLabel(v){return v==="unavailable"?"Unavailable":v==="review"?"Needs review":"Available";}
function classLabel(id){const c=classes.find(x=>x.id===id);return c?`${c.nameEn||id} — ${c.name||""}`:id||"—";}
function classLabels(ids=[]){return ids.length?ids.map(classLabel).join(", "):"—";}
function typeLabel(v){return v==="sharah"?"Commentary":"Matn";}
function nextId(){const nums=books.map(b=>Number(String(b.id||"").match(/KRL-(\d+)/i)?.[1]||0));return`KRL-${String(Math.max(0,...nums)+1).padStart(4,"0")}`;}

async function saveBook(andNew=false){const b=collectForm(),check=validateRecord(b);if(check.errors.length){showValidation(check.errors,"Fix these issues");notify("Please fix the required fields first.","error");return;}const btn=$("#saveBook");btn.disabled=true;try{await upsertBookToSupabase(b);const idx=books.findIndex(x=>x.id===b.id);if(idx>=0)books[idx]=b;else books.unshift(b);persist();editingId=b.id;selectedCover={path:b.cover,blob:null,fileName:b.cover?.split("/").pop()||""};notify(`${esc(b.id)} ${editingId===b.id&&idx>=0?"updated":"saved"} successfully.`,"success");setSyncState("ok","Saved to Supabase");formSnapshot="";if(andNew){resetForm();renderAdd();setView("add");}else{renderCatalogue();renderDashboard();updateNavigationMeta();setView("catalogue");}}catch(err){persist();try{await loadData({silent:true});}catch{}showValidation([`Supabase save failed: ${err?.message||"Unknown database error"}`],"Save failed — local safety cache preserved");notify("Save failed. Your local draft is preserved.","error");}finally{btn.disabled=false;}}
async function upsertBookToSupabase(b){const classIds=Array.isArray(b.classIds)?b.classIds:[];const row={id:b.id,title:b.title,title_en:b.titleEn||null,author:b.author||null,description:b.description||null,class_id:classIds[0]||null,book_type:b.bookType,pages:b.pages,cover_path:b.cover||null,pdf_url:b.pdfUrl||null,source_name:b.source?.name||null,source_page_url:b.source?.pageUrl||null,status:b.status,keywords:b.keywords||[],added_at:b.addedAt||today()};const r=await supabase.from("books").upsert(row,{onConflict:"id"});if(r.error)throw r.error;const dc=await supabase.from("book_classes").delete().eq("book_id",b.id);if(dc.error)throw dc.error;if(classIds.length){const ic=await supabase.from("book_classes").insert(classIds.map(class_id=>({book_id:b.id,class_id})));if(ic.error)throw ic.error;}const d=await supabase.from("book_categories").delete().eq("book_id",b.id);if(d.error)throw d.error;if(b.categoryIds?.length){const i=await supabase.from("book_categories").insert(b.categoryIds.map(category_id=>({book_id:b.id,category_id})));if(i.error)throw i.error;}}

function bookCardHtml(b){
  const cls=bookClassText(b), full=bookClassNames(b).join(", "), title=b.title||"Untitled";
  return `<article class="bk">
    <button class="bk-open" type="button" data-action="edit" data-id="${esc(b.id)}" aria-label="Edit ${esc(title)}">
      <span class="bk-cover">${b.cover?`<img src="${esc(b.cover)}" alt="" loading="lazy" decoding="async" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'cover-fallback',textContent:'📕'}))">`:icon("fa-book")}</span>
      <span class="bk-info">
        <strong class="bk-title" dir="auto">${esc(title)}</strong>
        <small class="bk-sub"><code>${esc(b.id)}</code><span class="${b.author?"":"none"}" dir="auto">${esc(b.author||"No author")}</span></small>
        <span class="bk-meta"><span class="bk-st ${esc(b.status)}">${esc(statusLabel(b.status))}</span><span class="bk-chip">${esc(typeLabel(b.bookType))}</span>${cls?`<span class="bk-chip" title="${esc(full)}">${esc(cls)}</span>`:""}${b.pages?`<span class="bk-chip">${b.pages} pages</span>`:""}</span>
      </span>
    </button>
    <button class="bk-more" type="button" data-action="menu" data-id="${esc(b.id)}" aria-label="More actions for ${esc(title)}" aria-haspopup="dialog">${icon("fa-ellipsis-vertical")}</button>
  </article>`;
}
function closeBookMenu(){const w=document.getElementById("bkMenuWrap");if(!w)return;const back=w._back;w.remove();document.documentElement.classList.remove("tx-lock");try{back?.focus?.({preventScroll:true});}catch{}}
function openBookMenu(id,trigger){
  const b=books.find(x=>x.id===id),host=document.querySelector(".cat-v2"); if(!b||!host)return; closeBookMenu();
  const item=(a,ic,t,s,cls="")=>`<button class="bk-act ${cls}" type="button" data-act="${a}"><span class="bk-act-ico">${icon(ic)}</span><span class="bk-act-txt"><strong>${t}</strong><small>${s}</small></span></button>`;
  const wrap=document.createElement("div"); wrap.className="tx-sheet-wrap"; wrap.id="bkMenuWrap"; wrap._back=trigger||null;
  wrap.innerHTML=`<section class="tx-sheet bk-menu" role="dialog" aria-modal="true" aria-labelledby="bkMenuTitle"><div class="tx-grab" aria-hidden="true"></div>
    <header class="tx-sheet-head"><div><h3 id="bkMenuTitle" class="bk-menu-title" dir="auto">${esc(b.title||"Untitled")}</h3><p>${esc(b.id)} · ${esc(statusLabel(b.status))}</p></div><button class="tx-x" type="button" id="bkMenuClose" aria-label="Close">${icon("fa-xmark")}</button></header>
    <div class="bk-menu-list">${item("edit","fa-pen","Edit","Open this record in the Add screen")}${item("preview","fa-eye","Preview","See a summary of the record")}${item("duplicate","fa-copy","Duplicate","Create a copy with a new ID")}${item("delete","fa-trash","Delete","Permanently remove this record","danger")}</div></section>`;
  host.appendChild(wrap); document.documentElement.classList.add("tx-lock");
  wrap.onclick=e=>{if(e.target===wrap)closeBookMenu();};
  $("#bkMenuClose").onclick=closeBookMenu;
  wrap.querySelectorAll("[data-act]").forEach(btn=>btn.onclick=()=>{const a=btn.dataset.act;closeBookMenu();handleRowAction(a,id);});
  try{wrap.querySelector(".bk-act").focus({preventScroll:true});}catch{}
}
function renderCatalogueRows(){
  const body=$("#bookRows"); if(!body)return;
  const qRaw=$("#catalogSearch")?.value||"", q=qRaw.trim().toLowerCase(), filter=$("#catalogFilter")?.value||"all", type=$("#catalogType")?.value||"all", sort=$("#catalogSort")?.value||"newest";
  Object.assign(catUi,{q:qRaw,status:filter,type,sort});
  const sc=$("#catalogSearchClear"); if(sc)sc.hidden=!qRaw;
  const filtered=!!q||filter!=="all"||type!=="all"; const clr=$("#clearFilters"); if(clr)clr.hidden=!filtered;
  let rows=books.filter(b=>{const hay=[b.id,b.title,b.titleEn,b.author,b.pdfUrl,b.source?.name,(b.keywords||[]).join(" "),bookClassNames(b).join(" ")].join(" ").toLowerCase();return(!q||hay.includes(q))&&(filter==="all"||b.status===filter)&&(type==="all"||b.bookType===type);});
  const by={newest:(a,b)=>String(b.addedAt||"").localeCompare(String(a.addedAt||"")),oldest:(a,b)=>String(a.addedAt||"").localeCompare(String(b.addedAt||"")),title:(a,b)=>String(a.title||"").localeCompare(String(b.title||""),"ur"),id:(a,b)=>String(a.id).localeCompare(String(b.id),undefined,{numeric:true})};
  rows=rows.slice().sort(by[sort]||by.newest);
  const badge=$("#countBadge"); if(badge)badge.textContent=!dataLoaded&&!books.length?"Loading…":(rows.length===books.length?`${books.length} book${books.length===1?"":"s"}`:`${rows.length} of ${books.length} books`);
  body.setAttribute("aria-busy",!dataLoaded&&!books.length?"true":"false");
  if(!dataLoaded&&!books.length){body.innerHTML=[0,1,2,3].map(()=>`<div class="bk bk-skel" aria-hidden="true"><span class="bk-cover"></span><span class="bk-info"><i class="sk" style="width:72%"></i><i class="sk" style="width:44%"></i><i class="sk" style="width:60%"></i></span></div>`).join("");return;}
  body.innerHTML=rows.length?rows.map(bookCardHtml).join(""):(books.length
    ?`<div class="tx-empty"><div class="tx-empty-ico">${icon("fa-magnifying-glass")}</div><strong>No matching books</strong><span>Try a different search or clear the filters.</span><button class="pill-btn" type="button" data-clear-filters>${icon("fa-rotate-left")} Clear filters</button></div>`
    :`<div class="tx-empty"><div class="tx-empty-ico">${icon("fa-book-open")}</div><strong>No books yet</strong><span>Add your first catalogue record.</span><button class="pill-btn primary" type="button" data-go="add">${icon("fa-plus")} Add book</button></div>`);
  body.querySelectorAll("[data-action]").forEach(btn=>btn.onclick=()=>{if(btn.dataset.action==="menu")openBookMenu(btn.dataset.id,btn);else handleRowAction(btn.dataset.action,btn.dataset.id);});
  body.querySelectorAll("[data-clear-filters]").forEach(b=>b.onclick=()=>$("#clearFilters")?.click());
}
function handleRowAction(action,id){const b=books.find(x=>x.id===id);if(!b)return;if(action==="edit"){fillForm(b);setView("add");}if(action==="preview"){fillForm(b);setView("add");setTimeout(previewRecord,0);}if(action==="duplicate")duplicateBook(b);if(action==="delete")deleteBook(b);}
function fillForm(b){editingId=b.id;renderAdd();$("#title").value=b.title;$("#titleEn").value=b.titleEn;$("#author").value=b.author;$("#description").value=b.description;renderClassPicker(b.classIds|| (b.classId?[b.classId]:[]));$("#type").value=b.bookType;renderCategoryPicker(b.categoryIds);$("#keywords").value=b.keywords.join(", ");$("#pdf").value=b.pdfUrl;$("#sourceType").value=b.source?.type||sourceTypeFromUrls(b.pdfUrl,b.source?.pageUrl,b.source?.name);$("#sourceName").value=b.source?.name||"";$("#sourcePage").value=b.source?.pageUrl||"";$("#pages").value=b.pages||"";$("#status").value=b.status;selectedCover={path:b.cover||"",blob:null,fileName:b.cover?.split("/").pop()||""};if(b.cover){$("#coverPreview").innerHTML=`<img src="${esc(b.cover)}" alt="Existing cover"><div class="cover-meta">${icon("fa-check-circle")} Existing cover</div>`;$("#coverStatus").className="status ready";$("#coverStatus").textContent="Existing cover";}updateSourceStatus();updateAddUi();snapshotForm();}
function resetForm(){editingId=null;selectedCover={path:"",blob:null,fileName:""};formSnapshot="";}
async function duplicateBook(b){const copy=structuredClone(b);copy.id=nextId();copy.title=`${b.title} (Copy)`;copy.addedAt=today();try{await upsertBookToSupabase(copy);books.unshift(copy);persist();renderCatalogue();renderDashboard();updateNavigationMeta();notify(`${esc(copy.id)} duplicated and saved.` ,"success");}catch(err){notify(`Duplicate failed: ${esc(err?.message||"Database error")}`,"error");}}
async function deleteBook(b){if(!await confirmDialog({title:`Delete ${b.id}?`,message:`"${b.title||"Untitled"}" will be permanently removed from the catalogue. This can't be undone.`,confirmText:"Delete",cancelText:"Keep",iconName:"fa-trash",tone:"danger"}))return;try{const d=await supabase.from("book_categories").delete().eq("book_id",b.id);if(d.error)throw d.error;const r=await supabase.from("books").delete().eq("id",b.id);if(r.error)throw r.error;books=books.filter(x=>x.id!==b.id);persist();if(editingId===b.id)resetForm();renderAllViews();setView("catalogue");notify(`${esc(b.id)} deleted.` ,"success");setSyncState("ok","Saved to Supabase");}catch(err){notify(`Delete failed: ${esc(err?.message||"Database error")}`,"error");}}
function previewRecord(book=collectForm()){const b=book;$("#result").innerHTML=`<div class="preview"><div class="cover">${b.cover?`<img src="${esc(b.cover)}" alt="" loading="lazy" decoding="async">`:icon("fa-image")}</div><div><h3>${esc(b.title||"Untitled")}</h3><p class="muted">${esc(b.id)} · ${esc(b.author||"No author")}</p><p>${esc(b.description||"No description")}</p><p>${esc(classLabels(b.classIds||[]))} · ${esc(typeLabel(b.bookType))} · ${b.pages?`${b.pages} pages`:"Page count not set"}</p><p class="muted">${esc(statusLabel(b.status))} · ${b.categoryIds.length} categories</p><p><strong>PDF:</strong> ${esc(b.pdfUrl||"—")}</p></div></div>`;}
function exportJSON(){const invalid=books.filter(b=>validateRecord(b).errors.length);if(invalid.length){notify(`Export blocked: ${invalid.length} invalid record(s).`,"error");return;}const a=document.createElement("a"),url=URL.createObjectURL(new Blob([JSON.stringify(books,null,2)],{type:"application/json"}));a.href=url;a.download="kr-urdu-library-books.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify("Catalogue backup exported.","success");}
async function importJSON(e){const file=e.target.files[0];e.target.value="";if(!file)return;try{const parsed=JSON.parse(await file.text());const incoming=Array.isArray(parsed)?parsed:parsed.books;if(!Array.isArray(incoming))throw Error("JSON must contain a books array.");const cleaned=incoming.map(normalizeImportedBook);const seenIds=new Set();const duplicateIds=[];cleaned.forEach((b,i)=>{if(b.id&&seenIds.has(b.id))duplicateIds.push(`Row ${i+1}: Duplicate ID ${b.id}.`);if(b.id)seenIds.add(b.id);});const bad=[...duplicateIds,...cleaned.flatMap((b,i)=>validateRecord(b).errors.map(x=>`Row ${i+1}: ${x}`))];if(bad.length){showValidation(bad.slice(0,40),"Import blocked");notify(`${bad.length} invalid issue(s). Import cancelled.`,"error");return;}let added=0,updated=0;for(const b of cleaned){const exists=books.some(x=>x.id===b.id);await upsertBookToSupabase(b);exists?updated++:added++;}await loadData({silent:true});notify(`Import complete — ${added} added, ${updated} updated.` ,"success");}catch(err){notify(`Import failed: ${esc(err?.message||"Invalid JSON")}`,"error");}}
function normalizeImportedBook(r){const pdfUrl=normalizeUrl(r.pdfUrl||r.pdf_url),pageUrl=normalizeUrl(r.source?.pageUrl||r.source_page_url);return{id:String(r.id||"").trim(),title:String(r.title||"").trim(),titleEn:String(r.titleEn||r.title_en||"").trim(),author:String(r.author||"").trim(),description:String(r.description||"").trim(),classIds:Array.isArray(r.classIds)?r.classIds.map(String):String(r.classId||r.class_id||"").trim()?[String(r.classId||r.class_id||"").trim()]:[],classId:String(r.classId||r.class_id||"").trim(),bookType:r.bookType==="sharah"?"sharah":"matn",categoryIds:Array.isArray(r.categoryIds)?r.categoryIds.map(String):csv(r.categoryIds),keywords:Array.isArray(r.keywords)?r.keywords.map(String):csv(r.keywords),cover:String(r.cover||r.cover_path||"").trim(),pdfUrl,source:{type:["archive","drive","direct"].includes(r.source?.type)?r.source.type:sourceTypeFromUrls(pdfUrl,pageUrl,r.source?.name||r.source_name||""),name:String(r.source?.name||r.source_name||"").trim(),pageUrl},pages:Number.isInteger(Number(r.pages))&&Number(r.pages)>0?Number(r.pages):null,status:["available","review","unavailable"].includes(r.status)?r.status:"review",addedAt:/^\d{4}-\d{2}-\d{2}$/.test(r.addedAt||"")?r.addedAt:today()};}
async function clearLocalDraft(){const ok=await confirmDialog({title:"Clear local cache?",message:"This does not delete anything from Supabase. Only the safety copy stored on this device is removed.",confirmText:"Clear cache",cancelText:"Keep",iconName:"fa-trash-can",tone:"danger"});if(!ok)return;localStorage.removeItem(STORAGE_KEY);notify("Local safety cache cleared. Supabase data is unchanged.","success");}

function archiveFileScore(f){
  const name=String(f?.name||""), n=name.toLowerCase();
  if(!n.endsWith(".pdf"))return -Infinity;
  const fmt=String(f?.format||"").toLowerCase();
  let score=100;
  if(fmt.includes("text pdf"))score+=40;
  else if(fmt.includes("image container pdf"))score+=25;
  else if(fmt.includes("pdf"))score+=30;
  if(String(f?.source||"").toLowerCase()==="original")score+=20;
  if(n.includes("_text.pdf"))score-=15;
  if(n.includes("_bw.pdf")||n.includes("_encrypted")||n.includes("_lcp"))score-=60;
  if(n.includes("/"))score-=10;
  const size=Number(f?.size||0);
  if(size>0)score+=Math.min(20,Math.log10(size));
  return score;
}
function parseInternetArchiveIdentifier(value){const raw=String(value||"").trim();if(!raw)return"";try{const u=new URL(raw),host=u.hostname.toLowerCase();if(host==="archive.org"||host.endsWith(".archive.org")){const m=u.pathname.match(/^\/details\/([^/?#]+)/i);if(m)return decodeURIComponent(m[1]);const d=u.pathname.match(/^\/download\/([^/?#]+)/i);if(d)return decodeURIComponent(d[1]);}}catch{}return/^[A-Za-z0-9._-]+$/.test(raw)?raw:"";}
function parseGoogleDriveFileId(value){const raw=String(value||"").trim();if(!raw)return"";try{const u=new URL(raw),host=u.hostname.toLowerCase();if(!host.endsWith("google.com")&&!host.endsWith("googleusercontent.com"))return"";const m=u.pathname.match(/\/file\/d\/([^/?#]+)/i);if(m)return m[1];const q=u.searchParams.get("id");if(q)return q;}catch{}const m=raw.match(/(?:drive\.google\.com\/file\/d\/|[?&]id=)([A-Za-z0-9_-]+)/i);return m?m[1]:"";}
function googleDriveDownloadUrl(id){return`https://drive.google.com/uc?export=download&id=${encodeURIComponent(id)}`;}
function updateSourceStatus(){const el=$("#sourceStatus");if(!el)return;const pdf=$("#pdf")?.value.trim()||"",page=$("#sourcePage")?.value.trim()||"",type=$("#sourceType")?.value||"auto";let detected=type==="auto"?sourceTypeFromUrls(pdf,page,$("#sourceName")?.value):type;let text="Not checked",cls="idle";if(pdf||page){if(detected==="archive"){text="Archive source";cls="ready";}else if(detected==="drive"){text="Google Drive source";cls="ready";}else if(isHttpUrl(pdf)){text="Direct PDF source";cls="ready";}else{text="Needs resolving";cls="error";}}el.className=`status ${cls}`;el.textContent=text;}
async function testSource(){
  const b=collectForm(),el=$("#sourceStatus"),btn=$("#testSource");
  if(!isHttpUrl(b.pdfUrl)){notify("Resolve or enter a valid PDF URL first.","error");return;}
  btn.disabled=true;el.className="status busy";el.textContent="Checking…";
  const done=(cls,label,msg,type)=>{el.className=`status ${cls}`;el.textContent=label;notify(msg,type);};
  try{
    const u=new URL(b.pdfUrl);
    if(b.source.type==="archive"&&!/(^|\.)archive\.org$/i.test(u.hostname))throw Error("Source is marked Internet Archive but the PDF host is not archive.org.");
    if(b.source.type==="drive"&&!/(^|\.)drive\.google\.com$|(^|\.)googleusercontent\.com$/i.test(u.hostname))throw Error("Source is marked Google Drive but the PDF URL is not a Google host.");
    if(b.source.type==="drive"&&b.source.pageUrl&&!parseGoogleDriveFileId(b.source.pageUrl))throw Error("Google Drive file ID could not be detected from the source URL.");
    // 1) Internet Archive: verify through the metadata API (it allows browser requests, file downloads do not)
    if(b.source.type==="archive"){
      const id=parseInternetArchiveIdentifier(b.pdfUrl),parts=u.pathname.split("/").filter(Boolean);
      if(id&&parts[0]==="download"&&parts.length>2){
        let meta=null;
        try{const r=await fetch(`https://archive.org/metadata/${encodeURIComponent(id)}`,{cache:"no-store"});if(r.ok)meta=await r.json();}catch{}
        if(meta&&Array.isArray(meta.files)&&meta.files.length){
          const file=decodeURIComponent(parts.slice(2).join("/"));
          if(!meta.files.some(f=>f.name===file))throw Error("This file name is not in the Archive item. Run Resolve source again.");
          done("ready","File found","PDF found in the Internet Archive item.","success");return;
        }
      }
    }
    // 2) Generic reachability: normal request first, then a no-cors ping (browsers hide the reply but still report whether the host answered)
    try{
      const r=await fetch(b.pdfUrl,{method:"HEAD",redirect:"follow",cache:"no-store"});
      if(r.ok||r.status===206){done("ready",`Reachable · ${r.status}`,`Source validated successfully (${r.status}).`,"success");return;}
      if(r.status===404||r.status===410)throw Error(`HTTP ${r.status} - file not found`);
      throw Error(`HTTP ${r.status}`);
    }catch(err){
      if(/^HTTP /.test(err?.message||""))throw err;
      try{await fetch(b.pdfUrl,{method:"HEAD",mode:"no-cors",cache:"no-store"});}
      catch{throw Error("Could not reach this link. Check your internet connection and the URL.");}
      done("ready","Link reachable","The link responds. Your browser hides the file details for this host, so this is normal.","success");return;
    }
  }catch(err){done("error","Check failed",`Source check failed: ${esc(err?.message||"Unknown error")}`,"error");}
  finally{btn.disabled=false;}
}
async function resolvePdfFromSource(){const source=$("#sourcePage").value.trim(),direct=$("#pdf").value.trim(),requestedType=$("#sourceType").value||"auto",input=source||direct;if(!input){notify("Paste a source page or PDF URL first.","error");return;}const driveId=parseGoogleDriveFileId(input);if(requestedType==="drive"||driveId){if(!driveId){notify("Google Drive file ID could not be detected. Paste a public Drive file URL.","error");return;}$("#sourceType").value="drive";$("#sourceName").value="Google Drive";$("#sourcePage").value=`https://drive.google.com/file/d/${encodeURIComponent(driveId)}/view`;$("#pdf").value=googleDriveDownloadUrl(driveId);notify("Google Drive source resolved to a direct download URL.","success");updateSourceStatus();snapshotForm();return;}if(isHttpUrl(input)&&/\.pdf(?:[?#].*)?$/i.test(input)){$("#sourceType").value=requestedType==="archive"?"archive":"direct";$("#pdf").value=normalizeUrl(input);if(!$("#sourcePage").value)$("#sourcePage").value=input;if(!$("#sourceName").value)$("#sourceName").value=requestedType==="archive"?"Internet Archive":"Direct PDF source";notify("Direct PDF accepted.","success");updateSourceStatus();snapshotForm();return;}const id=parseInternetArchiveIdentifier(input);if(!id){notify("Source not recognized. Use an Internet Archive item, a public Google Drive file, or a direct PDF URL.","error");return;}const btn=$("#resolveSource");btn.disabled=true;try{let r;try{r=await fetch(`https://archive.org/metadata/${encodeURIComponent(id)}`,{cache:"no-store"});}catch{throw Error("Could not reach archive.org. Check your internet connection and try again.");}if(!r.ok)throw Error(`Metadata request failed (${r.status}).`);const data=await r.json();if(!data||!Array.isArray(data.files)||!data.files.length)throw Error("Archive item not found, or it has no files. Check the link.");const pdfs=(data.files||[]).filter(f=>archiveFileScore(f)>-Infinity).sort((a,b)=>archiveFileScore(b)-archiveFileScore(a));if(!pdfs.length)throw Error("No PDF file found in this item.");const f=pdfs[0],name=String(f.name);$("#sourceType").value="archive";$("#pdf").value=`https://archive.org/download/${encodeURIComponent(id)}/${name.split("/").map(encodeURIComponent).join("/")}`;$("#sourcePage").value=`https://archive.org/details/${encodeURIComponent(id)}`;$("#sourceName").value="Internet Archive";const pages=Number(data.metadata?.imagecount||0);if(!$("#pages").value&&pages>0)$("#pages").value=pages;$("#result").innerHTML=`<div class="validation success-box"><strong>${icon("fa-circle-check")} PDF detected</strong><p>${esc(name)}</p><small>Internet Archive source resolved automatically.</small></div>`;notify("Internet Archive source resolved successfully.","success");updateSourceStatus();snapshotForm();}catch(err){notify(`Could not resolve PDF: ${esc(err?.message||"Unknown error")}`,"error");}finally{btn.disabled=false;}}
let pdfJsPromise=null;
async function loadPdfJs(){if(window.pdfjsLib?.getDocument)return window.pdfjsLib;if(!pdfJsPromise){pdfJsPromise=(async()=>{let last;for(const [m,w] of [["https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.mjs","https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.worker.mjs"],["https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs","https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs"]]){try{const mod=await import(m),pdfjs=mod?.default||mod;if(!pdfjs?.getDocument)throw Error("PDF.js API unavailable");pdfjs.GlobalWorkerOptions.workerSrc=w;window.pdfjsLib=pdfjs;return pdfjs;}catch(e){last=e;}}throw Error(`PDF.js unavailable: ${last?.message||"CDN failed"}`);})().catch(e=>{pdfJsPromise=null;throw e;});}return pdfJsPromise;}
async function generateCover(){const btn=$("#generateCover"),file=$("#coverFile").files[0],url=$("#pdf").value.trim(),isImage=file&&file.type.startsWith("image/");if(!file&&!isHttpUrl(url)){notify("Add a valid PDF URL, or select a local PDF or image first.","error");return;}btn.disabled=true;$("#coverStatus").className="status busy";$("#coverStatus").textContent="Generating…";let blob,fileName,drawSource,srcW,srcH,metaLabel;try{if(isImage){drawSource=await createImageBitmap(file);srcW=drawSource.width;srcH=drawSource.height;metaLabel="Uploaded image";}else{const pdfjs=await loadPdfJs(),pdf=file?await pdfjs.getDocument({data:await file.arrayBuffer()}).promise:await pdfjs.getDocument({url}).promise;const pageNo=Math.max(1,Math.min(Number($("#coverPage").value)||1,pdf.numPages));$("#coverPage").value=pageNo;if(!$("#pages").value)$("#pages").value=pdf.numPages;const page=await pdf.getPage(pageNo),base=page.getViewport({scale:1}),preScale=Math.max(600/base.width,900/base.height),vp=page.getViewport({scale:preScale}),src=document.createElement("canvas");src.width=Math.ceil(vp.width);src.height=Math.ceil(vp.height);await page.render({canvasContext:src.getContext("2d",{alpha:false}),viewport:vp}).promise;drawSource=src;srcW=vp.width;srcH=vp.height;metaLabel=`${pdf.numPages} pages`;}const targetW=600,targetH=900,out=document.createElement("canvas");out.width=targetW;out.height=targetH;const ctx=out.getContext("2d",{alpha:false});ctx.fillStyle="#fff";ctx.fillRect(0,0,targetW,targetH);const fit=$("#coverFit").value,ratio=fit==="contain"?Math.min(targetW/srcW,targetH/srcH):Math.max(targetW/srcW,targetH/srcH),dw=srcW*ratio,dh=srcH*ratio;ctx.drawImage(drawSource,(targetW-dw)/2,(targetH-dh)/2,dw,dh);blob=await new Promise((res,rej)=>out.toBlob(b=>b?res(b):rej(Error("WebP export failed")),"image/webp",.86));const id=editingId||nextId();fileName=`${id}-${slug($("#title").value)||"book"}.webp`;selectedCover={path:`./assets/covers/${fileName}`,blob,fileName};$("#coverPreview").innerHTML=`<img src="${URL.createObjectURL(blob)}" alt="Generated cover"><div class="cover-meta">${icon("fa-check-circle")} ${esc(fileName)} · ${esc(metaLabel)}</div>`;$("#downloadCover").disabled=false;}catch(err){$("#coverStatus").className="status error";$("#coverStatus").textContent="Generation failed";notify(`Cover generation failed: ${esc(err?.message||"Unknown error")}`,"error");btn.disabled=false;return;}$("#coverStatus").className="status busy";$("#coverStatus").textContent="Uploading to Supabase…";try{const up=await supabase.storage.from("covers").upload(fileName,blob,{contentType:"image/webp",upsert:true});if(up.error)throw up.error;const{data:pub}=supabase.storage.from("covers").getPublicUrl(fileName);selectedCover={path:pub.publicUrl,blob,fileName};$("#coverStatus").className="status ready";$("#coverStatus").textContent="Uploaded to Supabase";notify("Cover generated and uploaded to Supabase Storage.","success");}catch(err){$("#coverStatus").className="status error";$("#coverStatus").textContent="Upload failed — use Download Backup";notify(`Cover generated locally, but the Supabase upload failed: ${esc(err?.message||"Unknown error")}. Use "Download Backup" to save it and place it in assets/covers/ manually.`,"error");}finally{btn.disabled=false;snapshotForm();}}
function downloadCover(){if(!selectedCover.blob){notify("Generate a cover first.","warning");return;}const a=document.createElement("a"),url=URL.createObjectURL(selectedCover.blob);a.href=url;a.download=selectedCover.fileName;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify("Cover download started.","success");}

export function initManager(){ render(); }
