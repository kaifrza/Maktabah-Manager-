// Performance modes: auto | full | lite
// Applied as <html data-perf="full|lite"> so CSS can switch effects off on low-end phones.
const KEY = "krul_manager_perf_v1";
export const PERF_MODES = ["auto", "full", "lite"];

export function getPerfMode() {
  try { const v = localStorage.getItem(KEY); return PERF_MODES.includes(v) ? v : "auto"; }
  catch { return "auto"; }
}

// Heuristics only use signals that browsers actually expose (Chromium/Android mostly).
export function detectDevice() {
  const n = navigator;
  const mem = Number(n.deviceMemory) || 0;
  const cores = Number(n.hardwareConcurrency) || 0;
  const apple = /iPhone|iPad|iPod/i.test(n.userAgent || "");
  if (n.connection && n.connection.saveData) return { lite: true, reason: "Data Saver is on" };
  if (mem && mem <= 2) return { lite: true, reason: `low memory (${mem} GB)` };
  if (!apple && cores && cores <= 4) return { lite: true, reason: `${cores} CPU cores` };
  return { lite: false, reason: "capable device" };
}

export function resolvePerf(mode = getPerfMode()) {
  return mode === "auto" ? (detectDevice().lite ? "lite" : "full") : mode;
}

export function applyPerf() {
  const mode = getPerfMode();
  const eff = resolvePerf(mode);
  const root = document.documentElement;
  root.dataset.perf = eff;
  root.dataset.perfMode = mode;
  return eff;
}

export function setPerfMode(mode) {
  if (!PERF_MODES.includes(mode)) return resolvePerf();
  try { localStorage.setItem(KEY, mode); } catch { /* storage blocked: still apply for this session */ }
  const root = document.documentElement;
  const eff = resolvePerf(mode);
  root.dataset.perf = eff;
  root.dataset.perfMode = mode;
  return eff;
}

export const isLite = () => document.documentElement.dataset.perf === "lite";

applyPerf();
