-- KR Urdu Library Manager — Phase 1: Multi-Class Architecture
-- Applied to the live project during Phase 1.
-- Legacy public.books.class_id is intentionally retained for backward compatibility.

begin;

create table if not exists public.book_classes (
  book_id text not null references public.books(id) on delete cascade,
  class_id text not null references public.classes(id) on update cascade on delete cascade,
  created_at timestamptz not null default now(),
  primary key (book_id, class_id)
);

create index if not exists book_classes_class_id_idx
  on public.book_classes (class_id);

alter table public.book_classes enable row level security;

drop policy if exists "admin_insert_book_classes" on public.book_classes;
drop policy if exists "admin_update_book_classes" on public.book_classes;
drop policy if exists "admin_delete_book_classes" on public.book_classes;
drop policy if exists "admin_read_book_classes" on public.book_classes;
drop policy if exists "public_can_read_book_classes" on public.book_classes;
drop policy if exists "book_classes_read" on public.book_classes;

create policy "book_classes_read"
on public.book_classes for select
to anon, authenticated
using (
  (select is_admin())
  or exists (
    select 1
    from public.books b
    where b.id = book_classes.book_id
      and b.status in ('available','review')
  )
);

create policy "admin_insert_book_classes"
on public.book_classes for insert
to authenticated
with check ((select is_admin()));

create policy "admin_update_book_classes"
on public.book_classes for update
to authenticated
using ((select is_admin()))
with check ((select is_admin()));

create policy "admin_delete_book_classes"
on public.book_classes for delete
to authenticated
using ((select is_admin()));

grant select on public.book_classes to anon;
grant select, insert, update, delete on public.book_classes to authenticated;

insert into public.book_classes (book_id, class_id)
select id, class_id
from public.books
where class_id is not null
on conflict (book_id, class_id) do nothing;

commit;
