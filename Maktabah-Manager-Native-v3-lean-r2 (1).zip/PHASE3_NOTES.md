# KR Urdu Library Manager — Phase 3

## Category Management

Phase 3 adds a dedicated Categories manager without changing the database schema.

### Added
- New Categories navigation item on desktop and mobile.
- Category dashboard showing total, active, inactive, and books-with-category counts.
- Create category form with:
  - Category ID
  - Urdu name
  - English / Roman name
  - Sort order
  - Active/inactive visibility
- Edit existing categories.
- Activate/deactivate categories.
- Duplicate ID and duplicate-name validation.
- Strict category ID validation: lowercase letters, numbers, and hyphens.
- Existing category links are preserved when a category is deactivated.
- Inactive categories are hidden from the Add/Edit Book category picker.
- Existing active categories remain selectable.
- Mobile navigation expanded to five items.

## Database
No schema migration was required. The existing `public.categories` table already supports:
`id`, `name_ur`, `name_en`, `sort_order`, `is_active`, `created_at`, `updated_at`.

Existing RLS policies already permit authenticated admins to insert/update/delete categories and allow public reads of active categories. Phase 3 uses those existing policies.

## Safety
- Category deletion is intentionally not exposed in the UI. Deactivation is used instead so existing `book_categories` relationships remain intact.
- Inactive categories cannot be assigned to new or edited books.
- Existing books keep their historical category relationship.
