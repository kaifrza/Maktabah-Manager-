# KR Urdu Library Manager — Phase 14

## Glass Classes + Categories
- Both screens now render through one shared helper, `renderTaxonomy()` (config via `taxonomyConfig()`), in the same glass language as Home / Add / Catalogue / Tools.
- **Focus mode:** `setView()` toggles `body.focus-mode` on `categories` / `classes`. In that mode the global header and bottom nav are hidden.
- **Own header:** sticky glass sub-header with a Back button (`data-go="tools"` → Tools), title, and a "New" button. Browser/Android back also works (history is pushed per view).
- Layout: 4 glass stat cards → glass editor (glass inputs, switch for Active) → list as glass cards (Urdu name, English name, ID, sort, linked-book count, status, Edit / Deactivate buttons) instead of a wide table, so it works on phones.
- Added a linked-book count to Categories rows (Classes already had it).
- Activate / Deactivate confirmations now use the glass `confirmDialog` instead of native `confirm()`.
- All element ids, `data-category-*` / `data-class-*` attributes and save / validate / toggle logic are unchanged. No DB change.
- Not available on these two screens by design: refresh, theme toggle, sign-out, sync indicator (they live in the global header).
