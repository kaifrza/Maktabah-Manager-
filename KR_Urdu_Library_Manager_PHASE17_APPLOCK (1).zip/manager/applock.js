/* Maktabah Manager - optional local 6-digit App Lock (+ biometric).
   OFF by default. Turned on from More > App lock. PIN never leaves the device
   (salted SHA-256 in localStorage, no backend). Exposes window.MKLock. */
(function () {
  'use strict';
  var KEY = 'mk_lock_v1', FKEY = 'mk_lock_fail_v1', THEME_KEY = 'krul_manager_theme', AWAY = 10000;
  var cap = window.Capacitor;
  var native = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  var Bio = null, st = null, pin = '', first = '', stage = 'unlock', purpose = 'unlock';
  var busy = false, authing = false, locked = false, hiddenAt = 0, ov = null, T, S, D, K, C, KI;
  try { st = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}

  var CSS =
    '#mk-lock,#mk-lock *{box-sizing:border-box}' +
    '#mk-lock{--ink:#10261e;--soft:rgba(16,38,30,.62);--bg:rgba(255,255,255,.5);--bg2:rgba(255,255,255,.6);--bd:rgba(255,255,255,.78);--hi:inset 0 1px 0 rgba(255,255,255,.9);--sh:0 20px 48px rgba(16,50,38,.13);--em:#176b4d;--em2:#0f593f;--gold:#b8903a;--key:rgba(255,255,255,.62);--err:#b23a3a;' +
    'position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:calc(24px + env(safe-area-inset-top,0px)) 16px calc(24px + env(safe-area-inset-bottom,0px));color:var(--ink);font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;overflow:auto;' +
    'background:radial-gradient(520px 420px at 10% 6%,rgba(94,214,170,.6),transparent 70%),radial-gradient(480px 460px at 94% 16%,rgba(122,170,255,.45),transparent 70%),radial-gradient(560px 520px at 82% 94%,rgba(255,206,140,.5),transparent 70%),radial-gradient(520px 480px at 4% 88%,rgba(180,150,255,.36),transparent 70%),linear-gradient(160deg,#e3f2ea,#dde8f5)}' +
    '#mk-lock.dark{--ink:#edf4ee;--soft:rgba(237,244,238,.64);--bg:rgba(22,34,28,.52);--bg2:rgba(255,255,255,.08);--bd:rgba(255,255,255,.14);--hi:inset 0 1px 0 rgba(255,255,255,.1);--sh:0 20px 48px rgba(0,0,0,.4);--em:#4fbd8a;--em2:#3aa675;--gold:#d9b45a;--key:rgba(255,255,255,.09);--err:#ff9a9a;' +
    'background:radial-gradient(520px 420px at 10% 6%,rgba(40,170,120,.38),transparent 70%),radial-gradient(480px 460px at 94% 16%,rgba(70,100,210,.34),transparent 70%),radial-gradient(560px 520px at 82% 94%,rgba(210,150,60,.2),transparent 70%),radial-gradient(520px 480px at 4% 88%,rgba(120,80,200,.24),transparent 70%),linear-gradient(160deg,#08140f,#0b1220)}' +
    '#mk-lock .mkc{width:min(100%,400px);padding:30px 22px 22px;border-radius:34px;text-align:center;background:linear-gradient(145deg,var(--bg2),var(--bg));-webkit-backdrop-filter:blur(22px) saturate(165%);backdrop-filter:blur(22px) saturate(165%);border:1px solid var(--bd);box-shadow:var(--sh),var(--hi)}' +
    '#mk-lock .mkb{width:68px;height:68px;margin:0 auto 14px;display:grid;place-items:center;border-radius:22px;font-size:1.7rem;color:#a47c28;background:var(--bg2);border:1px solid rgba(184,144,58,.55);box-shadow:var(--hi),0 12px 24px rgba(16,50,38,.14)}' +
    '#mk-lock.dark .mkb{color:#e8c970}' +
    '#mk-lock .mkk{display:inline-block;padding:4px 12px;border-radius:999px;background:var(--bg2);border:1px solid var(--bd);box-shadow:var(--hi);font-size:.68rem;font-weight:800;letter-spacing:.05em;text-transform:uppercase;color:var(--gold)}' +
    '#mk-lock h1{margin:12px 0 0;font-size:1.55rem;line-height:1.2;font-weight:800;letter-spacing:-.02em;color:var(--ink)}' +
    '#mk-lock p{margin:6px 0 0;min-height:20px;font-size:.86rem;color:var(--soft)}' +
    '#mk-lock p.e{color:var(--err);font-weight:700}' +
    '#mk-d{display:flex;justify-content:center;gap:14px;margin:22px 0 24px}' +
    '#mk-d i{width:14px;height:14px;border-radius:50%;border:2px solid var(--gold);transition:background .12s,transform .12s}' +
    '#mk-d i.on{background:linear-gradient(135deg,var(--em),var(--em2));border-color:var(--em);transform:scale(1.12)}' +
    '#mk-k{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;justify-items:center}' +
    '#mk-k button{width:70px;height:70px;border-radius:50%;border:1px solid var(--bd);background:var(--key);box-shadow:var(--hi);color:var(--ink);font-family:inherit;font-size:1.5rem;font-weight:700;display:grid;place-items:center;cursor:pointer;touch-action:manipulation;-webkit-tap-highlight-color:transparent;transition:transform .1s,background .15s}' +
    '#mk-k button:active{transform:scale(.93);background:linear-gradient(135deg,var(--em),var(--em2));color:#fff}' +
    '#mk-k button.fn{font-size:1.25rem;color:var(--em)}' +
    '#mk-k button.x{visibility:hidden}' +
    '#mk-c{margin-top:16px;min-height:46px;padding:0 22px;border-radius:18px;border:1.5px solid var(--bd);background:var(--bg2);box-shadow:var(--hi);color:var(--ink);font-family:inherit;font-weight:750;font-size:.86rem;cursor:pointer;display:none}' +
    '#mk-lock .mkn{margin:16px 0 0;min-height:0;font-size:.74rem;color:var(--soft)}' +
    '#mk-lock .mkn i{margin-right:6px;color:var(--em)}' +
    '@media(max-height:640px){#mk-lock .mkc{padding:18px 16px 14px}#mk-lock .mkb{width:52px;height:52px;font-size:1.3rem;margin-bottom:8px}#mk-d{margin:14px 0 16px}#mk-k button{width:56px;height:56px;font-size:1.25rem}}' +
    'html[data-perf="lite"] #mk-lock .mkc{-webkit-backdrop-filter:none;backdrop-filter:none;background:rgba(255,255,255,.94)}' +
    'html[data-perf="lite"] #mk-lock.dark .mkc{background:rgba(24,36,29,.97)}' +
    'html[data-perf="lite"] #mk-lock *{transition:none!important}';

  function build() {
    if (ov) return;
    var st1 = document.createElement('style'); st1.textContent = CSS; document.head.appendChild(st1);
    ov = document.createElement('div');
    ov.id = 'mk-lock';
    ov.style.display = 'none';
    ov.setAttribute('role', 'dialog');
    ov.setAttribute('aria-modal', 'true');
    ov.innerHTML =
      '<section class="mkc">' +
      '<div class="mkb"><i class="fa-solid fa-book-open" aria-hidden="true"></i></div>' +
      '<span class="mkk">App Lock</span>' +
      '<h1 id="mk-t"></h1><p id="mk-s" aria-live="polite"></p>' +
      '<div id="mk-d" aria-hidden="true"></div><div id="mk-k"></div>' +
      '<button id="mk-c" type="button">Cancel</button>' +
      '<p class="mkn"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i>Your PIN stays on this device only</p>' +
      '</section>';
    document.body.appendChild(ov);
    T = ov.querySelector('#mk-t'); S = ov.querySelector('#mk-s');
    D = ov.querySelector('#mk-d'); K = ov.querySelector('#mk-k'); C = ov.querySelector('#mk-c');
    C.onclick = cancel;
  }
  function show() {
    build();
    ov.classList.toggle('dark', localStorage.getItem(THEME_KEY) === 'dark');
    ov.style.display = 'grid';
  }
  function hide() { if (ov) ov.style.display = 'none'; pin = ''; first = ''; }
  function changed() { try { window.dispatchEvent(new Event('mklockchange')); } catch (e) {} }

  function dots() {
    D.innerHTML = '';
    for (var i = 0; i < 6; i++) { var d = document.createElement('i'); if (i < pin.length) d.className = 'on'; D.appendChild(d); }
  }
  var TITLES = {
    unlock: ['Welcome back', 'Enter your PIN to unlock'],
    set: ['Create PIN', 'Choose a 6-digit PIN'],
    confirm: ['Confirm PIN', 'Enter the same PIN again'],
    old: ['Current PIN', 'Enter your current PIN to continue']
  };
  function ui(msg, err) {
    var t = TITLES[stage];
    T.textContent = t[0];
    S.textContent = msg || t[1];
    S.className = err ? 'e' : '';
    C.style.display = purpose === 'unlock' ? 'none' : 'inline-block';
    dots();
    K.innerHTML = '';
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'f', '0', 'b'].forEach(function (k) {
      var b = document.createElement('button');
      b.type = 'button';
      if (k === 'b') { b.className = 'fn'; b.setAttribute('aria-label', 'Delete'); b.innerHTML = '<i class="fa-solid fa-delete-left"></i>'; }
      else if (k === 'f') {
        if (st && st.bio && Bio && stage === 'unlock') { b.className = 'fn'; b.setAttribute('aria-label', 'Use biometrics'); b.innerHTML = '<i class="fa-solid fa-fingerprint"></i>'; }
        else b.className = 'x';
      } else b.textContent = k;
      b.onclick = function () { press(k); };
      K.appendChild(b);
    });
  }
  async function sha(s) {
    var b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
    return Array.from(new Uint8Array(b)).map(function (x) { return x.toString(16).padStart(2, '0'); }).join('');
  }
  function rnd() {
    var a = new Uint8Array(16); crypto.getRandomValues(a);
    return Array.from(a).map(function (x) { return x.toString(16).padStart(2, '0'); }).join('');
  }
  function save() { localStorage.setItem(KEY, JSON.stringify(st)); }
  function fail() { try { return JSON.parse(localStorage.getItem(FKEY)) || { n: 0, until: 0 }; } catch (e) { return { n: 0, until: 0 }; } }
  function wait() { var f = fail(); return f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0; }
  function wrong() {
    var f = fail(); f.n++;
    if (f.n % 5 === 0) f.until = Date.now() + Math.min(300, 30 * Math.pow(2, f.n / 5 - 1)) * 1000;
    localStorage.setItem(FKEY, JSON.stringify(f));
    var w = wait();
    ui(w ? 'Too many attempts. Try again in ' + w + 's.' : 'Incorrect PIN. Try again.', true);
    if (navigator.vibrate) navigator.vibrate(120);
  }

  var bioReady = (async function () {
    if (!native || !cap.registerPlugin) return;
    var names = ['BiometricAuthNative', 'BiometricAuth'];
    for (var i = 0; i < names.length; i++) {
      try {
        var p = cap.registerPlugin(names[i]);
        var r = await p.checkBiometry();
        if (r) { if (r.isAvailable) Bio = p; return; }
      } catch (e) {}
    }
  })();

  async function bioAuth(reason) {
    if (!Bio || authing) return false;
    authing = true;
    try {
      await Bio.authenticate({
        reason: reason || 'Unlock Maktabah Manager',
        cancelTitle: 'Use PIN',
        allowDeviceCredential: false,
        androidTitle: 'Maktabah Manager',
        androidSubtitle: 'Unlock with biometrics'
      });
      authing = false; return true;
    } catch (e) { authing = false; return false; }
  }
  async function tryBioUnlock() {
    if (locked && purpose === 'unlock' && stage === 'unlock' && st && st.bio && await bioAuth()) unlock();
  }
  function unlock() { locked = false; localStorage.removeItem(FKEY); hide(); }
  function lock() {
    if (!st || locked) return;
    locked = true; purpose = 'unlock'; stage = 'unlock'; pin = '';
    show(); ui();
    setTimeout(tryBioUnlock, 250);
  }
  function cancel() {
    if (purpose === 'unlock') return;
    purpose = 'unlock'; stage = 'unlock'; hide(); changed();
  }
  async function submit() {
    var p = pin; pin = '';
    if (stage === 'old') {
      if (await sha(st.salt + p) === st.hash) {
        if (purpose === 'disable') {
          st = null; localStorage.removeItem(KEY); localStorage.removeItem(FKEY);
          purpose = 'unlock'; stage = 'unlock'; hide(); changed();
        } else { stage = 'set'; ui(); }
      } else wrong();
      return;
    }
    if (stage === 'set') { first = p; stage = 'confirm'; ui(); return; }
    if (stage === 'confirm') {
      if (p !== first) { first = ''; stage = 'set'; ui('PINs did not match. Try again.', true); return; }
      var salt = rnd(), bio = !!(st && st.bio);
      st = { salt: salt, hash: await sha(salt + p), bio: bio }; save();
      purpose = 'unlock'; stage = 'unlock'; hide(); changed(); return;
    }
    if (await sha(st.salt + p) === st.hash) unlock(); else wrong();
  }
  async function press(k) {
    if (busy) return;
    if (k === 'f') { tryBioUnlock(); return; }
    if (stage === 'unlock' || stage === 'old') {
      var w = wait();
      if (w) { ui('Too many attempts. Try again in ' + w + 's.', true); return; }
    }
    if (k === 'b') { pin = pin.slice(0, -1); dots(); return; }
    if (pin.length >= 6) return;
    pin += k; dots();
    if (pin.length === 6) { busy = true; try { await submit(); } finally { busy = false; } }
  }

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { if (st && !locked && !authing) hiddenAt = Date.now(); }
    else { if (hiddenAt && Date.now() - hiddenAt > AWAY) lock(); hiddenAt = 0; }
  });

  function flow(p, s) {
    if (locked) return;
    purpose = p; stage = s; pin = ''; first = '';
    show(); ui();
  }
  window.MKLock = {
    isEnabled: function () { return !!st; },
    bioAvailable: async function () { await bioReady; return !!Bio; },
    bioEnabled: function () { return !!(st && st.bio); },
    setBio: async function (on) {
      await bioReady;
      if (!st || !Bio) return false;
      if (on && !(await bioAuth('Enable biometric unlock'))) return false;
      st.bio = !!on; save(); changed(); return true;
    },
    enable: function () { if (!st) flow('enable', 'set'); },
    changePin: function () { if (st) flow('change', 'old'); },
    disable: function () { if (st) flow('disable', 'old'); },
    lockNow: function () { lock(); }
  };

  // Optional: lock screen appears only if the user has turned App Lock on.
  if (st) {
    locked = true;
    show(); ui();
    bioReady.then(function () { if (locked) { ui(); tryBioUnlock(); } });
  }
})();
